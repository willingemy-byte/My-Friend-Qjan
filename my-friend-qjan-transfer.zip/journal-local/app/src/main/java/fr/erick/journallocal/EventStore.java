package fr.erick.journallocal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.Writer;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Locale;

public final class EventStore extends SQLiteOpenHelper {
    private static EventStore instance;
    private static final String PROCESS_SESSION=java.util.UUID.randomUUID().toString();
    private final Context context;
    public static volatile String lastError = "";
    public static synchronized EventStore get(Context context) {
        if (instance == null) instance = new EventStore(context.getApplicationContext());
        return instance;
    }
    private EventStore(Context context) { super(context, "journal.sqlite", null, 1); this.context=context;setWriteAheadLoggingEnabled(true); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp_ms INTEGER NOT NULL, app TEXT NOT NULL, action TEXT NOT NULL, destination TEXT NOT NULL, transport TEXT NOT NULL, category TEXT NOT NULL, payload TEXT NOT NULL, search_text TEXT NOT NULL)");
        db.execSQL("CREATE INDEX events_category ON events(category,id)");
        db.execSQL("CREATE INDEX events_time ON events(timestamp_ms,id)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { throw new IllegalStateException("Migration du journal requise; les données sont conservées."); }
    public static JSONObject object(Object... parts) {
        JSONObject out = new JSONObject();
        try { for(int i=0;i<parts.length;i+=2) out.put(String.valueOf(parts[i]), parts[i+1]); }
        catch(Exception e) { throw new IllegalArgumentException(e); }
        return out;
    }
    public synchronized boolean add(String category, String actor, String action, String destination, String transport, String source, JSONObject details) {
        try {
            long now = System.currentTimeMillis();
            JSONObject event = object("event_version",2,"collector_process_session",PROCESS_SESSION,"timestamp", Instant.ofEpochMilli(now).toString(), "timestamp_ms", now,
                "elapsed_ms", SystemClock.elapsedRealtime(), "app", actor, "action", action,
                "destination", destination, "transport", transport, "category", category,
                "source", source, "scope", ("trafic".equals(category)||"dns".equals(category)) ? "Métadonnées réseau observées par le VPN local; contenu des échanges non enregistré" : "Événement ou état fourni par une API Android; aucune capture du contenu des autres applications", "details", details);
            for(String key:new String[]{"protocol","port","bytes","direction","result"}) if(details.has(key)) event.put(key,details.get(key));
            ContentValues values = new ContentValues();
            values.put("timestamp_ms",now);values.put("app",actor);values.put("action",action);values.put("destination",destination);values.put("transport",transport);values.put("category",category);
            values.put("payload",event.toString());values.put("search_text",event.toString().toLowerCase(Locale.ROOT));
            getWritableDatabase().insertOrThrow("events",null,values);
            // Analysis errors have their own status and must never stop successful source recording.
            AnomalyMonitor.request(context);
            return true;
        } catch(Exception e) { lastError = "Écriture du journal impossible : " + e.getClass().getSimpleName(); return false; }
    }
    private static String literalLike(String text) { return text.replace("\\","\\\\").replace("%","\\%").replace("_","\\_"); }
    public synchronized JSONObject page(String search, String transport, int offset, int limit, long beforeId, String actor, String kind, boolean quiet) throws Exception {
        limit=Math.max(1,Math.min(100,limit));offset=Math.max(0,offset);
        SQLiteDatabase db=getReadableDatabase();
        long total, maxId;
        try(Cursor c=db.rawQuery("SELECT COUNT(*),COALESCE(MAX(id),0) FROM events",null)){c.moveToFirst();total=c.getLong(0);maxId=c.getLong(1);}
        long ceiling=beforeId>0?Math.min(beforeId,maxId):maxId;
        String where="id <= ?";ArrayList<String> args=new ArrayList<>();args.add(String.valueOf(ceiling));
        if(search!=null && !search.trim().isEmpty()){where+=" AND search_text LIKE ? ESCAPE '\\'";args.add("%"+literalLike(search.trim().toLowerCase(Locale.ROOT))+"%");}
        if(transport!=null && !transport.isEmpty()){where+=" AND transport = ?";args.add(transport);}
        if(actor!=null && !actor.isEmpty()){where+=" AND app = ?";args.add(actor);}
        if("apps".equals(kind))where+=" AND category IN ('trafic','dns')";
        if("system".equals(kind))where+=" AND category NOT IN ('trafic','dns')";
        JSONArray actors=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT DISTINCT app FROM events ORDER BY app COLLATE NOCASE LIMIT 1000",null)){while(c.moveToNext())actors.put(c.getString(0));}
        long matched,unmasked;
        try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM events WHERE "+where,args.toArray(new String[0]))){c.moveToFirst();unmasked=c.getLong(0);}
        boolean quietEffective=quiet&&(search==null||search.trim().isEmpty());
        if(quietEffective)where+=" AND NOT ((category='collecteur' AND action='Signal de vie') OR (category='reseau' AND action IN ('Compteurs réseau globaux','Lecture des compteurs réseau Android')) OR action='État de batterie reçu')";
        try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM events WHERE "+where,args.toArray(new String[0]))){c.moveToFirst();matched=c.getLong(0);}
        ArrayList<String> queryArgs=new ArrayList<>(args);queryArgs.add(String.valueOf(limit));queryArgs.add(String.valueOf(offset));
        JSONArray events=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT id,payload FROM events WHERE "+where+" ORDER BY id DESC LIMIT ? OFFSET ?",queryArgs.toArray(new String[0]))){
            while(c.moveToNext()){JSONObject event=new JSONObject(c.getString(1));event.put("id",c.getLong(0));events.put(event);}
        }
        return object("actors",actors,"events",events,"total",total,"matched",matched,"ceiling_id",ceiling,"latest_id",maxId,"offset",offset,"limit",limit,"quiet_effective",quietEffective,"hidden_count",unmasked-matched);
    }
    public long latestId(){try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(MAX(id),0) FROM events",null)){c.moveToFirst();return c.getLong(0);}}
    public JSONArray analysisBatch(long after,int limit)throws Exception{
        JSONArray result=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,payload FROM events WHERE id>? ORDER BY id LIMIT ?",new String[]{String.valueOf(after),String.valueOf(Math.max(1,Math.min(limit,200)))})){
            while(c.moveToNext()){JSONObject event=new JSONObject(c.getString(1));event.put("id",c.getLong(0));result.put(event);}
        }return result;
    }
    public JSONArray evidence(JSONArray ids)throws Exception{
        if(ids.length()>12)throw new IllegalArgumentException("Trop de références.");JSONArray result=new JSONArray();
        for(int i=0;i<ids.length();i++)try(Cursor c=getReadableDatabase().rawQuery("SELECT id,payload FROM events WHERE id=?",new String[]{String.valueOf(ids.getLong(i))})){
            if(c.moveToFirst()){JSONObject event=new JSONObject(c.getString(1));event.put("id",c.getLong(0));result.put(event);}
        }return result;
    }
    public void export(Writer writer)throws Exception{export(writer,false);}
    public void export(Writer writer,boolean jsonl)throws Exception{
        SQLiteDatabase db=getReadableDatabase();SnapshotExporter.write(writer,jsonl,new SnapshotExporter.Source(){
            public long[] snapshot(){try(Cursor c=db.rawQuery("SELECT COALESCE(MAX(id),0),COUNT(*) FROM events",null)){c.moveToFirst();return new long[]{c.getLong(0),c.getLong(1)};}}
            public java.util.List<String> page(long after,long ceiling)throws Exception{
                java.util.List<String> result=new java.util.ArrayList<>();try(Cursor c=db.rawQuery("SELECT id,payload FROM events WHERE id > ? AND id <= ? ORDER BY id ASC LIMIT 200",new String[]{String.valueOf(after),String.valueOf(ceiling)})){while(c.moveToNext()){JSONObject event=new JSONObject(c.getString(1));event.put("id",c.getLong(0));result.add(event.toString());}}return result;
            }
        });
    }
}
