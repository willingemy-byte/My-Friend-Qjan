package fr.erick.journallocal;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private WebView reader;
    private static final int NOTIFICATION_REQUEST=10,BLUETOOTH_REQUEST=11,EXPORT_REQUEST=12,VPN_REQUEST=13,ANALYSIS_EXPORT_REQUEST=14,LINES_EXPORT_REQUEST=15,RECOVER_IMPORT_REQUEST=16,RECOVER_EXPORT_REQUEST=17,DIAGNOSTIC_IMPORT_REQUEST=18,CORRELATION_EXPORT_REQUEST=19,LAST_EXPORT_REQUEST=20;
    private static volatile String fileStatus="";
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        AnomalyMonitor.request(this);
        reader=new WebView(this);
        reader.setOnApplyWindowInsetsListener((view,insets)->{
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);}
            else view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(reader);reader.requestApplyInsets();
        WebSettings settings=reader.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setBlockNetworkLoads(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setSupportMultipleWindows(false);
        WebView.setWebContentsDebuggingEnabled(false);
        reader.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return true;}
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return true;}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));}
        });
        reader.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest request){request.deny();}});
        reader.addJavascriptInterface(new Bridge(),"JournalAndroid");
        try(InputStream input=getAssets().open("journal.html")){
            ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1)data.write(buffer,0,count);
            reader.loadDataWithBaseURL("https://journal.local.invalid/",new String(data.toByteArray(),StandardCharsets.UTF_8),"text/html","UTF-8",null);
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Lecteur indisponible").setMessage(e.getClass().getSimpleName()).setPositiveButton("Fermer",(d,w)->finish()).show();}
    }
    public final class Bridge {
        @JavascriptInterface public String status(){
            boolean bluetoothAllowed=Build.VERSION.SDK_INT<31||checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
            return EventStore.object("running",RecorderService.running,"network",RecorderService.networkRegistered,"bluetooth",RecorderService.bluetoothRegistered,"bluetooth_enabled",getSharedPreferences("journal",MODE_PRIVATE).getBoolean("bluetooth",false),"bluetooth_permission",bluetoothAllowed,"last_alive_ms",RecorderService.lastAlive,"error",EventStore.lastError,"live_to_chatgpt",false,"capture",NetworkCaptureService.running,"capture_starting",NetworkCaptureService.starting,"capture_state",NetworkCaptureService.stateText,"capture_error",NetworkCaptureService.lastError).toString();
        }
        @JavascriptInterface public String page(String query,String transport,int offset,int limit,long ceiling,String actor,String kind,boolean quiet){
            try{if(query!=null&&query.length()>4096)throw new IllegalArgumentException("Recherche trop longue");return EventStore.get(MainActivity.this).page(query,transport,offset,limit,ceiling,actor,kind,quiet).toString();}
            catch(Exception e){return EventStore.object("error","Lecture impossible : "+e.getClass().getSimpleName()).toString();}
        }
        @JavascriptInterface public String diagnosticSummary(){try{return DiagnosticStore.get(MainActivity.this).summary().put("file_status",fileStatus).put("recovery",getSharedPreferences("files",0).getString("recovery_report","")).toString();}catch(Exception e){return EventStore.object("error",e.getMessage()).toString();}}
        @JavascriptInterface public String diagnosticConfigure(String value){try{return DiagnosticStore.get(MainActivity.this).configure(value).toString();}catch(Exception e){return EventStore.object("error",e.getMessage()).toString();}}
        @JavascriptInterface public String correlate(long eventId){try{
            org.json.JSONArray ids=new org.json.JSONArray();ids.put(eventId);org.json.JSONArray events=EventStore.get(MainActivity.this).evidence(ids);if(events.length()!=1)throw new IllegalArgumentException("Événement introuvable");
            org.json.JSONObject event=events.getJSONObject(0),result=DiagnosticStore.get(MainActivity.this).compare(event);getSharedPreferences("files",0).edit().putString("cross_analysis",EventStore.object("schema","journal-cross-analysis/1","source_event",event,"cross_analysis",result).toString()).apply();return result.toString();
        }catch(Exception e){return EventStore.object("error",e.getMessage()).toString();}}
        @JavascriptInterface public void command(String command){runOnUiThread(()->handleCommand(command));}
        @JavascriptInterface public String analysisSummary(){try{return AnomalyMonitor.get(MainActivity.this).summary().toString();}catch(Exception e){return EventStore.object("error","Lecture de l’analyse impossible : "+e.getClass().getSimpleName()).toString();}}
        @JavascriptInterface public String analysisPage(String kind,boolean unread,int offset){try{return AnomalyMonitor.get(MainActivity.this).page(kind,unread,offset).toString();}catch(Exception e){return EventStore.object("error","Lecture des signalements impossible : "+e.getClass().getSimpleName()).toString();}}
        @JavascriptInterface public String analysisEvidence(long id){try{return AnomalyMonitor.get(MainActivity.this).evidence(id).toString();}catch(Exception e){return EventStore.object("error","Événements sources indisponibles : "+e.getClass().getSimpleName()).toString();}}
        @JavascriptInterface public String analysisChange(String action,String value){try{return AnomalyMonitor.get(MainActivity.this).change(action,value).toString();}catch(Exception e){return EventStore.object("error",e instanceof IllegalArgumentException?e.getMessage():"Action d’analyse impossible : "+e.getClass().getSimpleName()).toString();}}
    }
    private void handleCommand(String command){
        try{
            if("start".equals(command)){
                EventStore.lastError="";
                if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST);
                else startCollector();
            }else if("stop".equals(command)){
                getSharedPreferences("journal",MODE_PRIVATE).edit().putBoolean("enabled",false).apply();
                if(RecorderService.running)startService(new Intent(this,RecorderService.class).setAction(RecorderService.STOP));
                stopService(new Intent(this,NetworkCaptureService.class));
            }else if("capture-on".equals(command)){
                Intent consent=android.net.VpnService.prepare(this);
                if(consent!=null)startActivityForResult(consent,VPN_REQUEST);else startNetworkCapture();
            }else if("capture-off".equals(command)){stopService(new Intent(this,NetworkCaptureService.class));
            }else if("recover-file".equals(command)||"import-diagnostic".equals(command)){
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");startActivityForResult(intent,"recover-file".equals(command)?RECOVER_IMPORT_REQUEST:DIAGNOSTIC_IMPORT_REQUEST);
            }else if("export-lines".equals(command)){chooseExport(LINES_EXPORT_REQUEST,"journal-cellulaire.jsonl","application/octet-stream");
            }else if("save-recovered".equals(command)){if(savedFile("recovered")==null)throw new IOException("Récupère d’abord un export");chooseExport(RECOVER_EXPORT_REQUEST,"journal-recupere.json","application/json");
            }else if("save-last-export".equals(command)){if(savedFile("last_export")==null)throw new IOException("Aucun instantané complet disponible");String ext=getSharedPreferences("files",0).getString("last_extension","json");chooseExport(LAST_EXPORT_REQUEST,"journal-copie."+ext,"application/octet-stream");
            }else if("export-correlation".equals(command)){if(getSharedPreferences("files",0).getString("cross_analysis","").isEmpty())throw new IOException("Ouvre un flux et lance une comparaison");chooseExport(CORRELATION_EXPORT_REQUEST,"journal-correlation.json","application/json");
            }else if("licenses".equals(command)){
                try(InputStream input=getAssets().open("licenses.txt")){
                    ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
                    while((n=input.read(buffer))!=-1)bytes.write(buffer,0,n);
                    new AlertDialog.Builder(this).setTitle("Sources et licences").setMessage(new String(bytes.toByteArray(),StandardCharsets.UTF_8)).setPositiveButton("Fermer",null).show();
                }
            }else if("bluetooth-on".equals(command)){
                if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},BLUETOOTH_REQUEST);
                else setBluetooth(true);
            }else if("bluetooth-off".equals(command)){setBluetooth(false);}
            else if("export".equals(command)){
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"journal-cellulaire.json");startActivityForResult(intent,EXPORT_REQUEST);
            }else if("export-analysis".equals(command)){
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"journal-analyse.json");startActivityForResult(intent,ANALYSIS_EXPORT_REQUEST);
            }
        }catch(Exception e){EventStore.lastError="Action impossible : "+e.getClass().getSimpleName();Toast.makeText(this,EventStore.lastError,Toast.LENGTH_LONG).show();}
    }
    private void startNetworkCapture(){NetworkCaptureService.lastError="";startForegroundService(new Intent(this,NetworkCaptureService.class));}
    private void startCollector(){startForegroundService(new Intent(this,RecorderService.class));}
    private void setBluetooth(boolean enabled){
        getSharedPreferences("journal",MODE_PRIVATE).edit().putBoolean("bluetooth",enabled).apply();
        EventStore.get(this).add("collecteur","Utilisateur",enabled?"Suivi Bluetooth demandé":"Suivi Bluetooth désactivé","Configuration du collecteur","Interne","Commande locale explicite",EventStore.object("enabled",enabled));
        if(RecorderService.running)startService(new Intent(this,RecorderService.class).setAction(RecorderService.REFRESH));
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==NOTIFICATION_REQUEST){try{startCollector();}catch(Exception e){EventStore.lastError="Démarrage impossible : "+e.getClass().getSimpleName();}}
        if(request==BLUETOOTH_REQUEST){boolean granted=grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED;setBluetooth(granted);if(!granted)Toast.makeText(this,"Suivi Bluetooth non activé.",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==VPN_REQUEST){
            if(result==RESULT_OK){try{startNetworkCapture();}catch(Exception e){NetworkCaptureService.lastError="Démarrage impossible : "+e.getClass().getSimpleName();}}
            else NetworkCaptureService.lastError="Capture non activée : autorisation VPN non accordée.";
            return;
        }
        if(result!=RESULT_OK||data==null||data.getData()==null)return;final Uri uri=data.getData();
        if(request==RECOVER_IMPORT_REQUEST||request==DIAGNOSTIC_IMPORT_REQUEST){
            fileStatus=request==RECOVER_IMPORT_REQUEST?"Récupération en cours…":"Lecture du diagnostic…";
            new Thread(()->{
                try{
                    if(request==DIAGNOSTIC_IMPORT_REQUEST){DiagnosticStore.get(this).ingest(uri);fileStatus=DiagnosticStore.activity;}
                    else{org.json.JSONObject[] report={null};File ready=ExportFiles.recover(this,uri,report);getSharedPreferences("files",0).edit().putString("recovered",ready.getAbsolutePath()).putString("recovery_report",report[0].toString()).apply();fileStatus=report[0].optLong("recovered_events")+" événements récupérés. Original conservé; copie séparée.";runOnUiThread(()->chooseExport(RECOVER_EXPORT_REQUEST,"journal-recupere.json","application/json"));}
                    runOnUiThread(()->Toast.makeText(this,fileStatus,Toast.LENGTH_LONG).show());
                }catch(Exception e){fileStatus="Lecture interrompue : "+e.getMessage();runOnUiThread(()->Toast.makeText(this,fileStatus,Toast.LENGTH_LONG).show());}
            },"journal-import").start();return;
        }
        if(request==EXPORT_REQUEST||request==ANALYSIS_EXPORT_REQUEST||request==LINES_EXPORT_REQUEST||request==RECOVER_EXPORT_REQUEST||request==CORRELATION_EXPORT_REQUEST||request==LAST_EXPORT_REQUEST){
            fileStatus="Préparation d’un instantané complet…";
            new Thread(()->{try{
                File ready;if(request==LAST_EXPORT_REQUEST)ready=savedFile("last_export");else if(request==RECOVER_EXPORT_REQUEST)ready=savedFile("recovered");
                else ready=ExportFiles.stage(this,writer->{if(request==ANALYSIS_EXPORT_REQUEST)AnomalyMonitor.get(this).export(writer);else if(request==CORRELATION_EXPORT_REQUEST){String cross=getSharedPreferences("files",0).getString("cross_analysis","");if(cross.isEmpty())throw new IOException("Comparaison indisponible");writer.write(cross);}else EventStore.get(this).export(writer,request==LINES_EXPORT_REQUEST);});
                if(ready==null)throw new IOException("Instantané expiré; recommencer la préparation");
                if(request!=LAST_EXPORT_REQUEST)getSharedPreferences("files",0).edit().putString("last_export",ready.getAbsolutePath()).putString("last_extension",request==LINES_EXPORT_REQUEST?"jsonl":"json").apply();
                fileStatus=ExportFiles.copy(this,ready,uri);runOnUiThread(()->Toast.makeText(this,fileStatus,Toast.LENGTH_LONG).show());
            }catch(Exception e){fileStatus="Export incomplet : "+e.getMessage()+". Si disponible, réenregistre le dernier instantané depuis Diagnostic.";runOnUiThread(()->Toast.makeText(this,fileStatus,Toast.LENGTH_LONG).show());}},"journal-export").start();
        }
    }
    private void chooseExport(int request,String name,String mime){try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,name),request);}catch(Exception e){fileStatus="Sélection du fichier impossible : "+e.getClass().getSimpleName();Toast.makeText(this,fileStatus,Toast.LENGTH_LONG).show();}}
    private File savedFile(String key)throws IOException{String value=getSharedPreferences("files",0).getString(key,"");if(value.isEmpty())return null;File f=new File(value);File dir=new File(getCacheDir(),"exports");if(!f.getCanonicalPath().startsWith(dir.getCanonicalPath()+File.separator)||!f.isFile())return null;return f;}
    @Override protected void onResume(){super.onResume();if(reader!=null)reader.onResume();}
    @Override protected void onPause(){if(reader!=null)reader.onPause();super.onPause();}
    @Override protected void onDestroy(){if(reader!=null){reader.removeJavascriptInterface("JournalAndroid");reader.destroy();}super.onDestroy();}
}
