"""Real loopback TCP/UDP/TLS, with a simulated TUN. Not an Android device test."""
import ctypes
import os
from pathlib import Path
import signal
import socket
import ssl
import struct
import subprocess
import threading
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/host-tests'

def checksum(data):
    if len(data)%2:data+=b'\0'
    value=sum(struct.unpack('!%dH'%(len(data)//2),data))
    while value>>16:value=(value&65535)+(value>>16)
    return (~value)&65535

def packet(version,proto,src,dst,body):
    family=socket.AF_INET if version==4 else socket.AF_INET6
    a,b=socket.inet_pton(family,src),socket.inet_pton(family,dst)
    pseudo=a+b+(struct.pack('!BBH',0,proto,len(body)) if version==4 else struct.pack('!I3xB',len(body),proto))
    body=bytearray(body);offset=16 if proto==6 else 6
    struct.pack_into('!H',body,offset,checksum(pseudo+body))
    if version==4:
        header=bytearray(struct.pack('!BBHHHBBH4s4s',0x45,0,20+len(body),0,0x4000,64,proto,0,a,b))
        struct.pack_into('!H',header,10,checksum(header))
    else:header=struct.pack('!IHBB16s16s',6<<28,len(body),proto,64,a,b)
    return bytes(header+body)

def parse(data):
    version=data[0]>>4;ih=(data[0]&15)*4 if version==4 else 40;proto=data[9] if version==4 else data[6]
    body=data[ih:];src_port,dst_port=struct.unpack('!HH',body[:4])
    result={'version':version,'proto':proto,'src_port':src_port,'dst_port':dst_port,'body':body,'raw':data}
    if proto==6:
        result.update(seq=struct.unpack('!I',body[4:8])[0],ack=struct.unpack('!I',body[8:12])[0],flags=body[13],payload=body[(body[12]>>4)*4:])
    else:result['payload']=body[8:]
    return result

class Harness:
    def __init__(self):
        self.sock,child=socket.socketpair(socket.AF_UNIX,socket.SOCK_DGRAM)
        self.sock.settimeout(5);self.lines=[];self.ready=threading.Event();self.closed=False
        self.proc=subprocess.Popen([str(BUILD/'relay-host'),str(child.fileno())],pass_fds=(child.fileno(),),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        child.close()
        def consume():
            for line in self.proc.stdout:
                self.lines.append(line.strip())
                if line.startswith('READY'):self.ready.set()
        self.reader=threading.Thread(target=consume,daemon=True);self.reader.start()
        if not self.ready.wait(5):raise RuntimeError('Host relay did not start')
    def send(self,data):self.sock.send(data)
    def recv(self):return parse(self.sock.recv(65535))
    def close(self):
        if self.closed:return
        self.closed=True;self.proc.send_signal(signal.SIGTERM)
        try:code=self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:self.proc.kill();self.proc.wait();raise
        self.reader.join(timeout=1);self.sock.close()
        error=self.proc.stderr.read();self.proc.stderr.close();self.proc.stdout.close()
        if code:raise AssertionError('Relay failed: '+str(code)+' '+error)
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

class Echo:
    def __init__(self,version,udp=False,tls=None):
        self.udp=udp;self.tls=tls;self.done=False
        self.sock=socket.socket(socket.AF_INET if version==4 else socket.AF_INET6,socket.SOCK_DGRAM if udp else socket.SOCK_STREAM)
        self.sock.bind(('127.0.0.1' if version==4 else '::1',0));self.port=self.sock.getsockname()[1];self.sock.settimeout(.2)
        if not udp:self.sock.listen(8)
        threading.Thread(target=self.serve,daemon=True).start()
    def serve(self):
        while not self.done:
            try:
                if self.udp:
                    data,peer=self.sock.recvfrom(65535);self.sock.sendto(data,peer)
                else:
                    client,_=self.sock.accept();threading.Thread(target=self.client,args=(client,),daemon=True).start()
            except socket.timeout:pass
            except OSError:break
    def client(self,client):
        try:
            client.settimeout(20)
            if self.tls:client=self.tls.wrap_socket(client,server_side=True)
            with client:
                while data:=client.recv(65536):client.sendall(data)
        except (OSError,ssl.SSLError):client.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.done=True;self.sock.close()

class TCP:
    def __init__(self,h,version,port,sport=42000):
        self.h=h;self.version=version;self.port=port;self.sport=sport;self.seq=10000;self.ack=0
        self.src='10.203.0.1' if version==4 else 'fd75:6a6f:7572::1';self.dst='127.0.0.1' if version==4 else '::1'
        self.send(b'',2);reply=self.h.recv()
        assert reply['flags']&18==18 and reply['ack']==self.seq+1,reply
        self.seq+=1;self.ack=reply['seq']+1;self.send(b'',16)
    def send(self,data,flags=24):
        body=struct.pack('!HHIIBBHHH',self.sport,self.port,self.seq,self.ack,0x50,flags,65535,0,0)+data
        self.h.send(packet(self.version,6,self.src,self.dst,body));self.seq=(self.seq+len(data))&0xffffffff
    def write(self,data):
        for at in range(0,len(data),1000):self.send(data[at:at+1000])
    def read(self):
        while True:
            p=self.h.recv()
            if p['proto']!=6 or p['dst_port']!=self.sport:continue
            if p['flags']&4:raise AssertionError('Unexpected TCP reset')
            data=p['payload']
            if data:
                assert p['seq']==self.ack,(p['seq'],self.ack)
                self.ack=(self.ack+len(data))&0xffffffff;self.send(b'',16);return data
    def exchange(self,data):
        self.write(data);out=b''
        while len(out)<len(data):out+=self.read()
        return out
    def close(self):self.send(b'',4)

class RelayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        BUILD.mkdir(parents=True,exist_ok=True);vendor=ROOT/'third_party/zdtun';cpp=ROOT/'app/src/main/cpp'
        common=['gcc','-O2','-D_LITTLE_ENDIAN','-DNO_DEBUG','-I'+str(vendor),'-I'+str(cpp),str(cpp/'relay.c'),str(cpp/'tls_sni.c'),str(vendor/'zdtun.c'),str(vendor/'utils.c')]
        subprocess.run(common+[str(ROOT/'tests/relay-host.c'),'-o',str(BUILD/'relay-host')],check=True)
        subprocess.run(common+['-shared','-fPIC','-o',str(BUILD/'relay-test.so')],check=True)
        cls.lib=ctypes.CDLL(str(BUILD/'relay-test.so'))
        cls.lib.journal_tls_new.argtypes=[ctypes.c_uint32];cls.lib.journal_tls_new.restype=ctypes.c_void_p
        cls.lib.journal_tls_feed.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_char_p,ctypes.c_size_t]
        cls.lib.journal_tls_name.argtypes=[ctypes.c_void_p];cls.lib.journal_tls_name.restype=ctypes.c_char_p
        cls.lib.journal_tls_ech.argtypes=[ctypes.c_void_p];cls.lib.journal_tls_free.argtypes=[ctypes.c_void_p]
        cls.lib.journal_dns_question.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_int)]
        subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost','-keyout',str(BUILD/'fixture.key'),'-out',str(BUILD/'fixture.crt')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    def test_dns_bounds(self):
        query=bytes.fromhex('123401000001000000000000')+b'\x07example\x03com\0\0\x01\0\x01'
        def decode(data):
            out=ctypes.create_string_buffer(256);kind=ctypes.c_int()
            ok=self.lib.journal_dns_question(data,len(data),out,256,ctypes.byref(kind));return ok,out.value,kind.value
        self.assertEqual(decode(query),(1,b'example.com',1))
        for end in range(len(query)):self.assertEqual(decode(query[:end])[0],0)
        self.assertEqual(decode(query[:12]+b'\xc0\x0c\0\x01\0\x01')[0],0)
        self.assertEqual(decode(query[:2]+b'\x81'+query[3:])[0],0)
    def test_tls_sni_reassembly_and_bounds(self):
        def hello(name=b'weather.example',ech=False,records=False):
            entry=b'\0'+struct.pack('!H',len(name))+name;sni=struct.pack('!H',len(entry))+entry;extensions=struct.pack('!HH',0,len(sni))+sni
            if ech:extensions+=struct.pack('!HH',0xfe0d,1)+b'\0'
            body=b'\x03\x03'+bytes(32)+b'\0\0\2\x13\x01\1\0'+struct.pack('!H',len(extensions))+extensions;msg=b'\1'+len(body).to_bytes(3,'big')+body;parts=[msg[:11],msg[11:]] if records else [msg]
            return b''.join(b'\x16\x03\x01'+struct.pack('!H',len(part))+part for part in parts)
        def decode(parts,base=1000):
            state=self.lib.journal_tls_new(base);self.assertTrue(state)
            try:
                result=0
                for offset,data in parts:result=self.lib.journal_tls_feed(state,(base+offset)&0xffffffff,data,len(data))
                return result,self.lib.journal_tls_name(state),self.lib.journal_tls_ech(state)
            finally:self.lib.journal_tls_free(state)
        wire=hello();self.assertEqual(decode([(0,wire)]),(1,b'weather.example',0))
        self.assertEqual(decode([(i,wire[i:i+1]) for i in range(len(wire))]),(1,b'weather.example',0))
        self.assertEqual(decode([(30,wire[30:]),(0,wire[:40])]),(1,b'weather.example',0))
        self.assertEqual(decode([(0,wire[:30]),(0,wire[:30]),(30,wire[30:])]),(1,b'weather.example',0))
        self.assertEqual(decode([(0,wire[:30]),(30,wire[30:])],0xfffffff0),(1,b'weather.example',0))
        self.assertEqual(decode([(0,hello(ech=True,records=True))]),(1,b'weather.example',1))
        for cut in range(len(wire)):self.assertEqual(decode([(0,wire[:cut])])[0],0)
        self.assertEqual(decode([(0,b'GET / HTTP/1.1\r\n')])[0],-1);self.assertEqual(decode([(0,wire[:30]),(12,b'\xff')])[0],-4);self.assertEqual(decode([(40000,b'x')])[0],-3)
        for name in [b'',b'.bad',b'bad.',b'-bad.example',b'x'*64+b'.example',b'bad\0name']:self.assertEqual(decode([(0,hello(name))])[0],-2)
        for index in range(3,len(wire)):
            mutated=bytearray(wire);mutated[index]=255;self.assertIn(decode([(0,bytes(mutated))])[0],[-4,-3,-2,-1,0,1])
    def test_udp_and_dns(self):
        for version in [4,6]:
            with self.subTest(version=version),Echo(version,udp=True) as echo,Harness() as h:
                payload=os.urandom(1024);body=struct.pack('!HHHH',41000,echo.port,len(payload)+8,0)+payload
                h.send(packet(version,17,'10.203.0.1' if version==4 else 'fd75:6a6f:7572::1','127.0.0.1' if version==4 else '::1',body))
                self.assertEqual(h.recv()['payload'],payload)
        with Harness() as h:
            query=bytes.fromhex('123401000001000000000000')+b'\x07example\x03com\0\0\x01\0\x01'
            h.send(packet(4,17,'10.203.0.1','127.0.0.77',struct.pack('!HHHH',42001,53,len(query)+8,0)+query))
            deadline=time.monotonic()+3
            while not any(line.startswith('DNS ') for line in h.lines) and time.monotonic()<deadline:time.sleep(.01)
            self.assertTrue(any('example.com 1' in line for line in h.lines))
    def test_tcp_byte_integrity(self):
        for version in [4,6]:
            with self.subTest(version=version),Echo(version) as echo,Harness() as h:
                tcp=TCP(h,version,echo.port)
                for size in [17,32768,2001]:
                    data=os.urandom(size);self.assertEqual(tcp.exchange(data),data)
                tcp.close()
    def test_preexisting_stream_reset(self):
        for version in [4,6]:
            with self.subTest(version=version),Harness() as h:
                src='10.203.0.1' if version==4 else 'fd75:6a6f:7572::1';dst='127.0.0.1' if version==4 else '::1'
                body=struct.pack('!HHIIBBHHH',43000,9,123,456,0x50,24,65535,0,0)+b'partial-stream'
                h.send(packet(version,6,src,dst,body));reply=h.recv()
                self.assertEqual(reply['flags'],4);self.assertEqual(reply['seq'],456);self.assertEqual(reply['dst_port'],43000)
                raw=reply['raw'];a,b=(raw[12:16],raw[16:20]) if version==4 else (raw[8:24],raw[24:40])
                pseudo=a+b+(struct.pack('!BBH',0,6,20) if version==4 else struct.pack('!I3xB',20,6))
                self.assertEqual(checksum(pseudo+reply['body']),0)
                if version==4:self.assertEqual(checksum(raw[:20]),0)
    def test_malformed_and_stop(self):
        h=Harness();h.send(b'\x60'*20);h.send(b'\x40'+b'\0'*19);time.sleep(.25);h.close()
        self.assertTrue(any('Paquets non décodés' in line for line in h.lines));self.assertIn('EXIT 0',h.lines)
    def test_persistent_verified_tls(self):
        server=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);server.load_cert_chain(BUILD/'fixture.crt',BUILD/'fixture.key')
        client=ssl.create_default_context(cafile=str(BUILD/'fixture.crt'))
        with Echo(4,tls=server) as echo,Harness() as h:
            tcp=TCP(h,4,echo.port);incoming,outgoing=ssl.MemoryBIO(),ssl.MemoryBIO();secure=client.wrap_bio(incoming,outgoing,server_hostname='localhost')
            def flush():
                while outgoing.pending:tcp.write(outgoing.read())
            while True:
                try:secure.do_handshake();flush();break
                except ssl.SSLWantReadError:flush();incoming.write(tcp.read())
            first=b'first-private-message';second=b'second-private-message-'+os.urandom(8192)
            for payload in [first,second]:
                secure.write(payload);flush();reply=b''
                while len(reply)<len(payload):
                    try:reply+=secure.read(65536)
                    except ssl.SSLWantReadError:flush();incoming.write(tcp.read())
                self.assertEqual(reply,payload);time.sleep(5.3)
            updates=[line.split() for line in h.lines if line.startswith('UPDATE ') and line.endswith(' 0')]
            self.assertEqual(sum(line.startswith('OPEN ') for line in h.lines),1)
            self.assertGreaterEqual(len(updates),2);self.assertGreater(int(updates[-1][2]),int(updates[0][2]))
            self.assertTrue(any(line.startswith('TLS ') and ' localhost 1 0' in line for line in h.lines),h.lines)
            self.assertNotIn(first.decode(),'\n'.join(h.lines));self.assertNotIn('second-private-message','\n'.join(h.lines));tcp.close()

if __name__=='__main__':unittest.main(verbosity=2)
