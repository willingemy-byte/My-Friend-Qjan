#include "relay.h"
#include <signal.h>
static volatile sig_atomic_t done;
static void finish(int sig){(void)sig;done=1;}
static int stop(void *p){(void)p;return done;}
static int protect_socket(void *p,int fd){(void)p;(void)fd;return 1;}
static void opened(void *p,uint64_t id,const zdtun_5tuple_t *t){(void)p;printf("OPEN %llu %u %u %u\n",(unsigned long long)id,t->ipver,t->ipproto,ntohs(t->dst_port));}
static void updated(void *p,uint64_t id,uint64_t tx,uint64_t rx,uint64_t txp,uint64_t rxp,int status,int error,int closed,uint64_t ms){
 (void)p;(void)ms;printf("UPDATE %llu %llu %llu %llu %llu %d %d %d\n",(unsigned long long)id,(unsigned long long)tx,(unsigned long long)rx,(unsigned long long)txp,(unsigned long long)rxp,status,error,closed);
}
static void dns(void *p,uint64_t id,const char *name,int type){(void)p;printf("DNS %llu %s %d\n",(unsigned long long)id,name,type);}
static void tls(void *p,uint64_t id,const char *name,int status,int ech){(void)p;printf("TLS %llu %s %d %d\n",(unsigned long long)id,name,status,ech);}
static void problem(void *p,const char *label,uint64_t count){(void)p;printf("PROBLEM %llu %s\n",(unsigned long long)count,label);}
int main(int argc,char **argv){
 if(argc!=2)return 2;int fd=atoi(argv[1]);fcntl(fd,F_SETFL,fcntl(fd,F_GETFL)|O_NONBLOCK);
 setvbuf(stdout,NULL,_IOLBF,0);signal(SIGTERM,finish);signal(SIGINT,finish);
 journal_listener listener={.should_stop=stop,.protect_socket=protect_socket,.opened=opened,.updated=updated,.dns_question=dns,.tls_hello=tls,.problem=problem};
 puts("READY");int result=journal_relay(fd,&listener);printf("EXIT %d\n",result);return result?1:0;
}
