package fr.erick.journallocal;
import java.io.*;
import java.util.*;

/** Behavioral fixtures, deliberately synthetic. Run without Android or external Java libraries. */
public final class AnomalyRulesTest {
    static long id;
    static int assertions;
    static void check(boolean result,String why){assertions++;if(!result)throw new AssertionError(why);}
    static AnomalyRules.Event event(long time){AnomalyRules.Event e=new AnomalyRules.Event();e.id=++id;e.wall=1800000000000L+time;e.elapsed=time;e.actor="App de test";e.uid=10001;e.packages=new String[]{"test.app"};return e;}
    static AnomalyRules.Event flow(long t,String key,long tx,boolean closed,String result){AnomalyRules.Event e=event(t);e.category="trafic";e.destination="192.0.2.10:443";e.flow=key;e.tx=tx;e.closed=closed;e.result=result;return e;}
    static AnomalyRules.Event dns(long t,String network,String...servers){AnomalyRules.Event e=event(t);e.category="reseau";e.source="ConnectivityManager.onLinkPropertiesChanged";e.destination=network;e.resolvers=servers;return e;}
    static AnomalyRules.Event query(long t,String name){AnomalyRules.Event e=event(t);e.category="dns";e.query=name;return e;}
    static long count(List<AnomalyRules.Finding> out,String rule){return out.stream().filter(f->f.rule.equals(rule)).count();}
    static AnomalyRules restart(AnomalyRules rules)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();try(ObjectOutputStream out=new ObjectOutputStream(b)){out.writeObject(rules);}try(ObjectInputStream in=new ObjectInputStream(new ByteArrayInputStream(b.toByteArray()))){return (AnomalyRules)in.readObject();}}
    public static void main(String[] args)throws Exception{
        AnomalyRules.Settings s=new AnomalyRules.Settings();s.uploadMiB=1;s.failureCount=3;s.validate();
        List<AnomalyRules.Finding> out=new ArrayList<>();AnomalyRules a=new AnomalyRules();
        a.accept(flow(1000,"a",-1,false,""),s,out::add);
        a.accept(flow(2000,"a",600000,false,"connecté"),s,out::add);
        a.accept(flow(3000,"a",600000,false,"connecté"),s,out::add);
        a.accept(flow(4000,"a",650000,false,"connecté"),s,out::add);
        check(out.isEmpty(),"Cumulative snapshots must not be summed");
        a.accept(flow(5000,"b",-1,false,""),s,out::add);a.accept(flow(6000,"b",500000,false,"connecté"),s,out::add);
        check(count(out,"volume")==1,"Delta totals across two flows trigger threshold");
        check(out.get(0).facts.get("Volume observé").equals("1150000 octets"),"Use exact observed increments");
        AnomalyRules.Event repeat=flow(7000,"b",500001,false,"connecté");a.accept(repeat,s,out::add);int once=out.size();a=restart(a);a.accept(repeat,s,out::add);
        check(out.size()==once,"A committed event cannot trigger again after restart");
        a.accept(flow(308000,"b",9000000,false,"connecté"),s,out::add);
        check(out.size()==once,"A counter gap longer than the window cannot be assigned to five minutes");
        a.accept(flow(309000,"b",9000001,false,"connecté"),s,out::add);
        check(out.size()==once,"Old buckets expire");
        a.accept(flow(310000,"orphan",50000000,false,"connecté"),s,out::add);
        check(out.size()==once&&a.uncertainCounters>0,"First counter without open/baseline is marked uncertain, not an upload burst");
        a.accept(flow(311000,"b",1,false,"connecté"),s,out::add);check(out.size()==once,"Counter reset is not an upload");

        a=new AnomalyRules();out.clear();
        for(int i=0;i<8;i++){a.accept(flow(1000+i*100,"reset"+i,0,true,"réinitialisé"),s,out::add);a.accept(flow(1050+i*100,"closed"+i,20,true,"fermé"),s,out::add);}
        check(out.isEmpty(),"Ordinary closes and synthetic startup resets are not failures");
        AnomalyRules.Event failed=flow(2000,"failed1",0,true,"erreur de socket");a.accept(failed,s,out::add);
        AnomalyRules.Event duplicate=flow(2100,"failed1",0,true,"erreur de socket");a.accept(duplicate,s,out::add);
        a.accept(flow(2200,"failed2",0,true,"injoignable"),s,out::add);check(count(out,"failures")==0,"One flow counts only once");
        a.accept(flow(2300,"failed3",0,true,"erreur"),s,out::add);check(count(out,"failures")==1,"Three distinct failed flows trigger");
        a.accept(flow(303000,"failed4",0,true,"erreur"),s,out::add);check(count(out,"failures")==1,"Errors outside rolling window expire");

        a=new AnomalyRules();out.clear();a.accept(dns(100000,"network1","1.1.1.1","9.9.9.9"),s,out::add);a.accept(dns(100100,"network1","9.9.9.9","1.1.1.1"),s,out::add);a.accept(dns(100200,"network2","8.8.8.8"),s,out::add);
        check(out.isEmpty(),"Initial DNS, order changes, and new network are not DNS changes");
        AnomalyRules.Event changed=dns(100300,"network1","8.8.8.8");a.accept(changed,s,out::add);
        check(count(out,"dns")==1&&out.get(0).evidence.size()==2,"A real DNS change keeps both source ids");check(out.get(0).facts.get("Avant").contains("1.1.1.1"),"DNS before retained");
        a=restart(a);a.accept(dns(100400,"network1","8.8.8.8"),s,out::add);check(out.size()==1,"Restart preserves DNS baseline");
        a.accept(dns(1000,"network1","4.4.4.4"),s,out::add);check(out.size()==1,"New boot does not compare a reused network id");
        a.accept(dns(1100,"empty"),s,out::add);a.accept(dns(1200,"empty","1.1.1.1"),s,out::add);check(out.size()==1,"Empty initial DNS is a baseline, not a suspicious change");
        AnomalyRules.Event started=event(1500);started.category="collecteur";started.action="Collecte démarrée";a.accept(started,s,out::add);a.accept(dns(1600,"network1","7.7.7.7"),s,out::add);check(out.size()==1,"New collection session prevents comparison with old boot or session even if uptime increased");

        a=new AnomalyRules();out.clear();s.domains=new String[]{"ExAmple.ORG."};s.validate();check(s.domains[0].equals("example.org"),"Normalize case and trailing dot");
        a.accept(query(1000,"api.example.org"),s,out::add);a.accept(query(1100,"api.example.org."),s,out::add);
        check(count(out,"watch")==2&&out.get(0).key.equals(out.get(1).key),"A/AAAA observations share a group key");
        a.accept(query(1200,"notexample.org"),s,out::add);a.accept(query(1300,"example.org.attacker.test"),s,out::add);check(out.size()==2,"Suffix boundaries prevent substring false positives");
        a.accept(query(1400,"service.c2s.ic.gov"),s,out::add);check(out.get(2).type.equals("trace")&&out.get(2).rule.equals("research"),"Report correspondence is a trace, not intrusion verdict");
        a.accept(query(1500,"c2s.ic.gov.evil.test"),s,out::add);a.accept(query(1600,"example.com"),s,out::add);check(out.size()==3,"Lookalike and example OTEL endpoint excluded");
        check(!AnomalyRules.researchMatch("bedrock-runtime-fips.us-east-1.amazonaws.com").isEmpty(),"Bedrock domain pattern");
        check(AnomalyRules.researchMatch("evilbedrock-runtime-fips.us-east-1.amazonaws.com").isEmpty(),"Bedrock boundary");
        AnomalyRules.Event otlp=flow(1700,"otlp",-1,false,"");otlp.port=4317;otlp.destination="192.0.2.20:4317";a.accept(otlp,s,out::add);
        AnomalyRules.Event otlpUpdate=flow(1800,"otlp",42,false,"connecté");otlpUpdate.port=4317;otlpUpdate.destination=otlp.destination;a.accept(otlpUpdate,s,out::add);
        check(count(out,"research-port")==1,"Port hint emitted once per flow, separately from anomalies");
        AnomalyRules.Event https=flow(1900,"https",-1,false,"");https.port=443;a.accept(https,s,out::add);check(count(out,"research-port")==1,"HTTPS alone is not a telemetry indication");
        for(String invalid:new String[]{"https://example.org","*.example.org","<img>example.org","192.0.2.1","example..org"})check(AnomalyRules.domain(invalid).isEmpty(),"Reject invalid domain: "+invalid);
        s.domains=new String[]{"https://example.org"};boolean invalid=false;try{s.validate();}catch(IllegalArgumentException e){invalid=true;}check(invalid,"Settings reject URLs atomically");s.domains=new String[0];

        a=new AnomalyRules();out.clear();AnomalyRules.Event gap=event(1000);gap.category="collecteur";gap.action="Intervalle sans signal de vie";gap.interval=240000;a.accept(gap,s,out::add);
        AnomalyRules.Event stop=event(2000);stop.category="collecteur";stop.action="Capture arrêtée";stop.coverageGap=true;a.accept(stop,s,out::add);
        AnomalyRules.Event reconfigure=event(3000);reconfigure.category="collecteur";reconfigure.action="Changement du réseau de capture";reconfigure.coverageGap=true;a.accept(reconfigure,s,out::add);
        check(out.size()==1&&out.get(0).rule.equals("collection"),"Gap diagnostic is separated from ordinary stop/reconfiguration");
        AnomalyRules.Event problem=event(4000);problem.category="collecteur";problem.action="Erreur de capture réseau";problem.problem="IOException";a.accept(problem,s,out::add);check(out.size()==2,"Explicit capture error produces diagnostic");

        a=new AnomalyRules();out.clear();for(int i=0;i<5;i++){
            AnomalyRules.Event e=flow(1000+i*100,"unknown"+i,9000000,true,"erreur");e.uid=-1;e.packages=new String[0];a.accept(e,s,out::add);
        }check(out.isEmpty()&&a.unknownAttribution==5,"Unknown actors not combined into a fake per-app signal");
        AnomalyRules.Event shared=flow(2000,"shared",5000000,true,"erreur");shared.packages=new String[]{"app.a","app.b"};a.accept(shared,s,out::add);check(out.isEmpty(),"Shared UID not attributed to a specific app");
        AnomalyRules.Event global=event(2200);global.category="reseau";global.tx=900000000;global.action="Lecture des compteurs réseau Android";a.accept(global,s,out::add);check(out.isEmpty(),"Global since-boot counters never count as per-app upload");
        s.watch=false;s.research=false;a.accept(query(2300,"service.c2s.ic.gov"),s,out::add);check(out.isEmpty(),"Disabled research rule stays off");
        a=new AnomalyRules();out.clear();s.volume=true;
        a.accept(flow(100000,"clock",-1,false,""),s,out::add);AnomalyRules.Event backward=flow(101000,"clock",1200000,false,"connecté");backward.wall=1;a.accept(backward,s,out::add);check(out.size()==1,"Wall-clock rollback does not break monotonic measurement");
        a=new AnomalyRules();out.clear();AnomalyRules.Event system=flow(1000,"system",-1,false,"");system.uid=1000;system.packages=new String[]{"single.visible.candidate"};a.accept(system,s,out::add);
        system=flow(2000,"system",90000000,false,"connecté");system.uid=1000;system.packages=new String[]{"single.visible.candidate"};a.accept(system,s,out::add);check(count(out,"volume")==0,"UID 1000 excluded even when only one package is visible");
        a=new AnomalyRules();out.clear();s.watch=true;s.domains=new String[]{"example.org"};AnomalyRules.Event sni=flow(3000,"sni",-1,false,"");sni.action="Nom TLS observé";sni.query="api.example.org";a.accept(sni,s,out::add);check(count(out,"watch")==1,"Visible SNI participates in domain rules");
        AnomalyRules.Event outer=flow(4000,"outer",-1,false,"");outer.action="Nom TLS externe possible (ECH/GREASE)";outer.query="api.example.org";a.accept(outer,s,out::add);check(count(out,"watch")==1,"ECH/GREASE excluded from destination rules");
        System.out.println("PASS: "+assertions+" behavioral checks; synthetic fixtures, no phone data.");
    }
}
