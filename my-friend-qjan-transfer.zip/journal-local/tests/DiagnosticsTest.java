package fr.erick.journallocal;
import java.io.*;
import java.util.*;
import org.json.*;
public final class DiagnosticsTest {
    static int checks;static void check(boolean ok,String name){checks++;if(!ok)throw new AssertionError(name);}
    static String row(long id){return EventStore.object("id",id,"timestamp_ms",1789025866579L+id,"app","UID partagé 1000","action","Flux réseau observé","details",EventStore.object("text","Accents é } ] { "+(char)34+" et retour\n","uid",1000)).toString();}
    static final class Growing implements SnapshotExporter.Source {
        final List<String> rows=new ArrayList<>();boolean broken=false;
        Growing(){for(int i=1;i<=5;i++)rows.add(row(i));}public long[] snapshot(){return new long[]{5,5};}
        public List<String> page(long after,long ceiling){rows.add(row(rows.size()+1));List<String> out=new ArrayList<>();for(String r:rows){long id=new JSONObject(r).getLong("id");if(id>after&&id<=(broken?4:ceiling)){out.add(r);if(out.size()==2)break;}}return out;}
    }
    static JSONObject recover(String s,List<String> rows)throws Exception{return JournalRecovery.recover(new StringReader(s),rows::add);}
    static String exported(boolean lines)throws Exception{StringWriter out=new StringWriter();Growing source=new Growing();SnapshotExporter.write(out,lines,source);check(source.rows.size()>5,"source appends during export");return out.toString();}
    public static void main(String[] args)throws Exception{
        String json=exported(false);JSONObject export=new JSONObject(json);check(export.getJSONArray("events").length()==5,"fixed snapshot count");check(export.getJSONObject("integrity").getBoolean("complete"),"completion footer");
        List<String> got=new ArrayList<>();JSONObject report=recover(json,got);check(got.size()==5&&report.getBoolean("document_complete")&&report.getString("source_integrity").equals("verifiee"),"roundtrip and checksum");check(new JSONObject(got.get(0)).getJSONObject("details").getString("text").contains("retour\n"),"escaped strings retained");
        for(int cut=0;cut<json.length();cut++){got.clear();report=recover(json.substring(0,cut),got);check(!report.getBoolean("document_complete")&&got.size()<=5,"truncated document never complete");for(int i=0;i<got.size();i++)check(new JSONObject(got.get(i)).getLong("id")==i+1,"ordered prefix only");}
        got.clear();report=recover(json.replace("UID partagé 1000","UID partagé 1001"),got);check(report.getString("source_integrity").equals("echec"),"tamper detected");
        got.clear();report=recover("{\"events\":["+row(1)+",{oops:1},"+row(3)+"]}",got);check(got.size()==1&&!report.getBoolean("document_complete"),"corrupt array stops at first failure");
        got.clear();report=recover("{\"events\":["+row(1)+"],\"events\":["+row(2)+"]}",got);check(got.size()==1&&!report.getBoolean("document_complete"),"duplicate events key rejected");
        String lines=exported(true);got.clear();report=recover(lines,got);check(got.size()==5&&report.getString("source_integrity").equals("verifiee"),"JSONL roundtrip");
        got.clear();report=recover(lines.substring(0,lines.lastIndexOf("{\"")),got);check(got.size()==5&&!report.getBoolean("document_complete"),"truncated JSONL footer");
        got.clear();report=recover(row(1)+"\n{bad}\n"+row(3)+"\n",got);check(got.size()==2&&report.getLong("rejected_records")==1,"JSONL damaged independent line skipped");
        got.clear();report=recover(lines+row(6)+"\n",got);check(got.size()==5&&!report.getBoolean("document_complete"),"data after footer rejected");
        check(!JsonSyntax.valid("{\"a\":1,}")&&!JsonSyntax.valid("{a:1}")&&!JsonSyntax.valid("[01]")&&!JsonSyntax.valid("[NaN]")&&!JsonSyntax.valid("\"bad\n\""),"strict JSON grammar");
        check(!JsonSyntax.valid(new String(new char[70]).replace("\0","[")+"0"+new String(new char[70]).replace("\0","]")),"bounded nesting");
        Growing broken=new Growing();broken.broken=true;try{SnapshotExporter.write(new StringWriter(),false,broken);throw new AssertionError("incomplete snapshot accepted");}catch(IOException expected){checks++;}
        try{SnapshotExporter.write(new Writer(){public void write(char[] c,int o,int n)throws IOException{throw new IOException("disk full");}public void flush(){}public void close(){}},false,new Growing());throw new AssertionError("write failure swallowed");}catch(IOException expected){checks++;}
        JSONObject flow=EventStore.object("id",1,"timestamp_ms",1789025866579L,"details",EventStore.object("first_observed_ms",1789025866579L,"uid",1000,"protocol","TCP","local_ip","10.203.0.1","local_port",42000,"remote_ip","3.19.178.229","port",443));
        JSONObject d=DiagnosticParser.parse("1789025866.579123456 1000 222 333 I netd: observed 3.19.178.229:443",2026,-240);
        check(d.getLong("timestamp_ms")==1789025866579L&&d.getInt("pid")==222,"epoch nanoseconds truncated to milliseconds");check(DiagnosticParser.match(flow,d).equals("endpoint_and_time"),"endpoint mention is a candidate");check(d.isNull("process_name"),"tag is not a package");
        JSONObject temporal=DiagnosticParser.parse("1789025866.579 999 888 I DiagMonAgent: unrelated message",2026,0);check(DiagnosticParser.match(flow,temporal).equals("temporal")&&temporal.isNull("process_name"),"no package attribution by coincidence");
        JSONObject socket=EventStore.object("schema","journal-socket-evidence/1","timestamp_ms",1789025866579L,"pid",222,"uid",1000,"protocol","TCP","local_ip","10.203.0.1","local_port",42000,"remote_ip","3.19.178.229","remote_port",443,"process_name","system_server","source","synthetic test");
        d=DiagnosticParser.parse(socket.toString(),2026,0);check(DiagnosticParser.match(flow,d).equals("socket_tuple_reported"),"complete tuple and UID");d.put("uid",1001);check(!DiagnosticParser.match(flow,d).equals("socket_tuple_reported"),"wrong UID excluded");d.put("uid",1000).put("local_port",42001);check(!DiagnosticParser.match(flow,d).equals("socket_tuple_reported"),"wrong local socket excluded");
        d=DiagnosticParser.parse("2026-09-10 03:37:46.579 222 333 I Tag: message",2026,-240);check(d.getLong("timestamp_ms")==java.time.Instant.parse("2026-09-10T07:37:46.579Z").toEpochMilli(),"explicit timezone");
        d=DiagnosticParser.parse("09-10 03:37:46.579 222 333 I Tag: message",2026,-240);check(d.getString("time_basis").contains("année"),"year assumption stated");check(DiagnosticParser.parse("DiagMonAgent uses AWS",2026,0)==null,"undated narrative not evidence");
        check(DiagnosticParser.sameIp("2001:db8::1","2001:0db8:0:0:0:0:0:1")&&!DiagnosticParser.numericIp("example.org")&&!DiagnosticParser.numericIp("999.1.1.1"),"numeric IP only; no DNS lookup");
        System.out.println("PASS: "+checks+" checks — truncation points, concurrent appends, recovery, integrity, time/PID/tuple. Host only, no Android document provider or SQLite exercised.");
    }
}
