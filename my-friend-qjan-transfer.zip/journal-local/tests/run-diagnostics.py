"""Use a test-only JSON-java 20250517 jar, ECJ and Java 17; nothing is bundled in the APK."""
import argparse, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--ecj',type=Path,required=True);p.add_argument('--json-jar',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];out=root/'build/host-diagnostics';out.mkdir(parents=True,exist_ok=True)
sources=[root/'tests/host-stubs/EventStore.java',root/'tests/DiagnosticsTest.java']+[root/'app/src/main/java/fr/erick/journallocal'/f for f in ['JsonSyntax.java','JournalRecovery.java','SnapshotExporter.java','DiagnosticParser.java']]
subprocess.run(['java','-jar',str(a.ecj),'-encoding','UTF-8','-source','1.8','-target','1.8','-cp',str(a.json_jar),'-d',str(out),*map(str,sources)],check=True)
subprocess.run(['java','-cp',str(out)+':'+str(a.json_jar),'fr.erick.journallocal.DiagnosticsTest'],check=True)
