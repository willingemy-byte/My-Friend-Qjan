// Interface integration tests with a simulated Android bridge, not a device test.
// Install jsdom 26.1.0 in a separate development directory and set NODE_PATH.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require('jsdom');

const records = [];
const commands = [];
let running = false, bluetooth = false, failRead = false, capture = false;
let scheduledPoll;
const findings=[];
let settings={failures:true,volume:true,dns:true,collection:true,watch:true,research:true,failure_count:8,upload_mib:10,domains:[],quiet:true};
const isNoise=e=>(e.category==='collecteur'&&e.action==='Signal de vie')||(e.category==='reseau'&&['Compteurs réseau globaux','Lecture des compteurs réseau Android'].includes(e.action))||e.action==='État de batterie reçu';
function add(action, transport = 'Interne') {
  records.push({ id: records.length + 1, timestamp: new Date().toISOString(), app: 'Android',
    action, transport, category: 'systeme', destination: 'Ressource observée', source: 'API simulée pour ce test',
    details: { marker: 'test-only' } });
}
const bridge = {
  status: () => JSON.stringify({running, network: running, bluetooth: running && bluetooth,
    bluetooth_enabled: bluetooth, last_alive_ms: running ? Date.now() : 0, error: '', capture, capture_starting: false, capture_state: capture ? 'Actif' : 'Arrêté', capture_error: ''}),
  page(query, transport, offset, limit, ceiling, actor, kind, quiet) {
    if (failRead) return JSON.stringify({error: 'Base temporairement indisponible'});
    const anchor = ceiling || records.length;
    const base = records.filter(e => e.id <= anchor && (!transport || e.transport === transport) &&
      (!actor || e.app === actor) && (kind !== 'apps' || ['trafic','dns'].includes(e.category)) && (kind !== 'system' || !['trafic','dns'].includes(e.category)) && JSON.stringify(e).toLowerCase().includes(query.toLowerCase())).reverse();
    const found=base.filter(e=>!quiet||query.trim()||!isNoise(e));
    return JSON.stringify({events: found.slice(offset, offset + limit), total: records.length,
      matched: found.length, ceiling_id: anchor, actors: [...new Set(records.map(e => e.app))],hidden_count:base.length-found.length});
  },
  diagnosticSummary(){return JSON.stringify({settings:{year:2026,utc_offset_minutes:-240,window_seconds:2},records:1,imports:[],file_status:'',recovery:'',activity:'',error:''});},
  diagnosticConfigure(value){const s=JSON.parse(value);return JSON.stringify(s.year<1970?{error:'Année invalide'}:s);},
  correlate(eventId){return JSON.stringify({event_id:eventId,interpretation:'Proximité temporelle seulement. Attribution non établie.',lines_in_window:1,lines_examined:1,window_ms_each_side:2000,candidates:[{match:'temporal',pid:222,delta_ms:123,import_id:1,source_line:4,tag:'<img src=x onerror="window.pwned=true">',time_basis:'epoch UTC',scope:'PID du rédacteur, pas nécessairement du socket.'}]});},
  analysisSummary(){return JSON.stringify({processed:records.length,checkpoint:records.length,latest:records.length,busy:false,unread:findings.filter(f=>f.kind==='anomaly'&&!f.reviewed).length,traces:findings.filter(f=>f.kind==='trace').length,error:'',settings});},
  analysisPage(kind,unread,offset){const selected=findings.filter(f=>f.kind===kind&&(!unread||!f.reviewed));return JSON.stringify({rows:selected.slice(offset,offset+15),total:selected.length});},
  analysisEvidence(){return JSON.stringify({events:records.slice(-2)});},
  analysisChange(action,value){
    if(action==='review')findings.find(f=>f.id===Number(value)).reviewed=true;
    if(action==='settings'){
      const input=JSON.parse(value);
      if(input.domains.some(d=>d.includes('://')))return JSON.stringify({error:'Domaine invalide : utiliser un nom seul.'});
      settings=input;
    }
    return JSON.stringify({ok:true,settings});
  },
  command(command) {
    commands.push(command);
    if (command === 'start') { running = true; add('Collecte démarrée'); }
    if (command === 'capture-on') capture = true;
    if (command === 'capture-off') capture = false;
    if (command === 'stop') { capture = false; running = false; add('Collecte arrêtée'); }
    if (command === 'bluetooth-on') bluetooth = true;
    if (command === 'bluetooth-off') bluetooth = false;
  }
};
const errors = [];
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', e => errors.push(e.message));
const dom = new JSDOM(fs.readFileSync(path.join(__dirname, '../app/src/main/assets/journal.html'), 'utf8'), {
  url: 'https://journal.local.invalid/', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole,
  beforeParse(window) {
    window.JournalAndroid = bridge;
    window.TextEncoder = TextEncoder;
    window.TextDecoder = TextDecoder;
    window.HTMLElement.prototype.scrollIntoView = function() {};
    const interval = window.setInterval.bind(window);
    window.setInterval = (callback, delay) => {
      assert.equal(delay, 3000);
      scheduledPoll = callback;
      return interval(callback, delay);
    };
  }
});
const doc = dom.window.document;
const byId = id => doc.getElementById(id);
const rows = () => [...doc.querySelectorAll('#jc-events li')];
const click = id => byId(id).click();
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
function change(id, value, event = 'change') {
  byId(id).value = value;
  byId(id).dispatchEvent(new dom.window.Event(event, {bubbles: true}));
}

(async () => {
  assert.deepEqual(errors, []);
  assert.equal(rows().length, 0, 'No invented activity at startup');
  assert.equal(byId('jc-import-toggle').hidden, true, 'No file required in native mode');
  assert.ok(byId('jc-permission-count').textContent.includes('aucune activité déduite'));
  assert.equal(commands.includes('capture-on'), false, 'No VPN activation just by opening the reader');
  click('jc-start-native');
  await delay(1350);
  assert.equal(rows().length, 1);
  assert.equal(byId('jc-start-native').disabled, true);
  add('Alimentation branchée');
  await delay(3250);
  assert.equal(rows().length, 2, 'New source event appears through automatic polling');
  assert.ok(rows()[0].textContent.includes('Alimentation branchée'));

  add('Réseau par défaut reçu', 'Cellulaire');
  scheduledPoll();
  assert.equal(rows()[0].querySelector('.jc-chip').textContent, 'Cellulaire', 'Do not invent an LTE/5G generation');
  change('jc-transport', 'Cellulaire');
  assert.equal(rows().length, 1);
  change('jc-transport', '');

  const untrusted = '<img src=x onerror="window.pwned=true">';
  add(untrusted);
  scheduledPoll();
  assert.ok(rows()[0].textContent.includes(untrusted));
  assert.equal(doc.querySelector('#jc-events img'), null);
  assert.equal(dom.window.pwned, undefined);
  rows()[0].querySelector('button').click();
  assert.equal(byId('jc-detail').hidden, false);
  assert.ok(byId('jc-detail').textContent.includes('test-only'));
  assert.ok(byId('jc-detail').textContent.includes('Stockage local'));
  assert.ok(!byId('jc-detail').textContent.includes('non vérifié sur le téléphone'));
  add('Écran allumé');
  scheduledPoll();
  assert.equal(rows().length, 4, 'Selected detail remains stable as new data arrives');
  byId('jc-detail').querySelector('button').click();
  scheduledPoll();
  assert.equal(rows().length, 5);

  for (let i = 0; i < 30; i++) add('Événement '+i);
  scheduledPoll();
  assert.equal(rows().length, 15);
  click('jc-next');
  const anchored = rows().map(e => e.querySelector('button').dataset.key);
  add('Événement arrivé pendant la lecture');
  scheduledPoll();
  assert.deepEqual(rows().map(e => e.querySelector('button').dataset.key), anchored, 'Stable pagination during collection');
  click('jc-prev');
  assert.ok(rows()[0].textContent.includes('Événement arrivé pendant la lecture'));
  change('jc-search', 'Alimentation branchée', 'input');
  assert.equal(rows().length, 1);
  change('jc-search', 'aucun-résultat-pour-ce-test', 'input');
  assert.equal(rows().length, 0);
  assert.equal(byId('jc-empty').hidden, false);
  change('jc-search', '', 'input');

  click('jc-export');
  assert.equal(commands.at(-1), 'export');
  assert.equal(byId('jc-export-panel').hidden, true, 'Native export uses Android destination picker');
  doc.querySelector('[data-jc-tab="sources"]').click();
  click('jc-bluetooth-native');
  assert.equal(commands.at(-1), 'bluetooth-on');
  scheduledPoll();
  assert.ok(byId('jc-pane-sources').textContent.includes('suivi activé'));
  doc.querySelector('[data-jc-tab="journal"]').click();
  click('jc-stop-native');
  await delay(1300);
  assert.equal(byId('jc-stop-native').disabled, true);
  assert.ok(rows()[0].textContent.includes('Collecte arrêtée'));

  click('jc-capture-native');
  assert.equal(commands.at(-1), 'capture-on');
  records.push({id: records.length + 1, timestamp: new Date().toISOString(), app: 'ChatGPT', action: 'Trafic observé', transport: 'Wi-Fi', category: 'trafic', destination: '192.0.2.1:443', details: {marker: 'test-only'}});
  scheduledPoll();
  change('jc-kind', 'apps');
  change('jc-app', 'ChatGPT');
  assert.equal(rows().length, 1);
  assert.ok(rows()[0].textContent.includes('ChatGPT'));
  assert.ok(rows()[0].textContent.includes('Destination contactée : 192.0.2.1:443'));
  change('jc-kind', 'system');
  assert.equal(rows().length, 0);
  change('jc-app', '');
  assert.ok(rows().every(e => !e.textContent.includes('ChatGPT')));
  change('jc-kind', '');
  click('jc-capture-native');
  assert.equal(commands.at(-1), 'capture-off');
  scheduledPoll();
  assert.equal(byId('jc-stop-native').disabled, true);

  failRead = true;
  scheduledPoll();
  assert.equal(byId('jc-error').hidden, false);
  assert.ok(byId('jc-error').textContent.includes('Base temporairement indisponible'));
  failRead = false;
  scheduledPoll();
  assert.equal(byId('jc-error').hidden, true, 'Recovered read clears temporary error');

  records.push({id:records.length+1,timestamp:new Date().toISOString(),app:'Journal local',action:'Signal de vie',category:'collecteur',transport:'Interne',destination:'Collecteur'});
  scheduledPoll();
  assert.ok(!rows().some(e=>e.textContent.includes('Signal de vie')),'Routine noise hidden by default');
  assert.ok(byId('jc-filter-count').textContent.includes('1 lignes répétitives masquées'));
  change('jc-quiet','all');assert.ok(rows()[0].textContent.includes('Signal de vie'));
  change('jc-quiet','quiet');
  change('jc-search','Signal de vie','input');assert.equal(rows().length,1,'Search includes hidden source events');
  change('jc-search','','input');
  const recordCount=records.length;
  click('jc-analysis-tab');assert.equal(byId('jc-pane-journal').hidden,true);
  assert.ok(byId('jc-analysis-empty').textContent.includes('Aucune règle déclenchée'));
  assert.ok(byId('jc-pane-anomalies').textContent.includes('Non collecté ici'));
  findings.push({id:1,kind:'anomaly',rule:'volume',title:'Seuil de trafic envoyé dépassé',actor:'App de test',severity:'attention',first_ms:Date.now(),last_ms:Date.now(),occurrences:3,reviewed:false,explanation:'Deltas de compteurs',advice:'Comparer avec une sauvegarde',facts:{'Seuil':'10 Mio / 5 minutes'}});
  findings.push({id:2,kind:'trace',rule:'research',title:'Correspondance avec le rapport',actor:'App de test',severity:'information',first_ms:Date.now(),last_ms:Date.now(),occurrences:2,reviewed:false,explanation:'DNS observé',advice:'Pas une preuve de contenu',facts:{Domaine:untrusted}});
  scheduledPoll();assert.ok(byId('jc-analysis-tab').textContent.includes('1'));
  assert.equal(doc.querySelectorAll('#jc-analysis-list li').length,1);
  doc.querySelector('#jc-analysis-list button').click();assert.equal(byId('jc-analysis-detail').hidden,false);
  assert.ok(byId('jc-analysis-detail').textContent.includes('Deltas de compteurs'));
  assert.ok(byId('jc-analysis-detail').textContent.includes('Événements sources'));
  const frozen=byId('jc-analysis-detail').textContent;scheduledPoll();assert.equal(byId('jc-analysis-detail').textContent,frozen,'Analysis detail not replaced while reading');
  click('jc-analysis-reviewed');assert.equal(findings[0].reviewed,true);
  click('jc-analysis-close');
  byId('jc-analysis-unread').checked=true;byId('jc-analysis-unread').dispatchEvent(new dom.window.Event('change'));
  assert.equal(doc.querySelectorAll('#jc-analysis-list li').length,0);
  change('jc-analysis-kind','trace');assert.equal(doc.querySelectorAll('#jc-analysis-list li').length,1);
  doc.querySelector('#jc-analysis-list button').click();assert.ok(byId('jc-analysis-detail').textContent.includes(untrusted));assert.equal(doc.querySelector('#jc-analysis-detail img'),null);
  click('jc-analysis-close');
  byId('jc-analysis-settings').open=true;await delay(30);
  change('jc-rule-count','12','input');change('jc-rule-domains','https://example.org','input');click('jc-analysis-save');
  assert.ok(byId('jc-analysis-message').textContent.includes('Domaine invalide'));
  assert.equal(byId('jc-analysis-settings').open,true);
  scheduledPoll();assert.equal(byId('jc-rule-count').value,'12','Polling does not reset edited controls');
  change('jc-rule-domains','example.org','input');click('jc-analysis-save');
  assert.equal(settings.failure_count,12);assert.deepEqual(settings.domains,['example.org']);
  assert.equal(byId('jc-analysis-settings').open,false);
  click('jc-analysis-export');assert.equal(commands.at(-1),'export-analysis');
  assert.equal(records.length,recordCount,'Filters and reviews never delete source events');
  doc.querySelector('[data-jc-tab="diagnostic"]').click();assert.equal(byId('jc-pane-diagnostic').hidden,false);assert.equal(byId('jt-year').value,'2026');
  change('jt-year','2027','input');scheduledPoll();assert.equal(byId('jt-year').value,'2027');
  change('jt-year','1960','input');const before=commands.length;click('jt-import');assert.equal(commands.length,before);
  change('jt-year','2026','input');click('jt-import');assert.equal(commands.at(-1),'import-diagnostic');
  click('jt-export-lines');assert.equal(commands.at(-1),'export-lines');click('jt-recover');assert.equal(commands.at(-1),'recover-file');click('jt-save-last');assert.equal(commands.at(-1),'save-last-export');
  doc.querySelector('[data-jc-tab="journal"]').click();
  records.push({id:records.length+1,timestamp:new Date().toISOString(),app:'UID partagé 1000',action:'Nom TLS observé',category:'trafic',transport:'Wi-Fi',destination:'192.0.2.1:443',details:{uid:1000,packages:['candidate.one','candidate.two'],tls_sni:'example.org',tls_observation:'ClientHello observé',sni_scope:'Nom déclaré, pas contenu.'}});
  scheduledPoll();rows()[0].querySelector('button').click();assert.ok(byId('jc-detail').textContent.includes('2 paquets candidats'));assert.ok(byId('jc-detail').textContent.includes('example.org'));
  click('jt-correlate');assert.ok(byId('jt-correlation-result').textContent.includes('Attribution non établie'));assert.ok(byId('jt-correlation-result').textContent.includes('<img'));assert.equal(doc.querySelector('#jt-correlation-result img'),null);click('jt-export-correlation');assert.equal(commands.at(-1),'export-correlation');
  assert.equal(dom.window.pwned,undefined);
  assert.deepEqual(errors, []);
  process.stdout.write('PASS: collection controls, original-event preservation, noise filtering and full search, source details, anomaly and trace separation, automatic badge, stable evidence, review, validated settings, export, untrusted text, pagination and error recovery.\n');
  process.stdout.write('Scope: DOM + simulated Android bridge. No Android runtime or Samsung hardware exercised.\n');
})().catch(error => { process.stderr.write(error.stack+'\n'); process.exitCode = 1; })
  .finally(() => dom.window.close());
