package fr.erick.journallocal;
import org.json.JSONObject;
/** Test-only JSON factory. Android persistence is not simulated here. */
public final class EventStore {
    public static JSONObject object(Object... p){JSONObject j=new JSONObject();for(int i=0;i<p.length;i+=2)j.put(String.valueOf(p[i]),p[i+1]);return j;}
}
