# Journal local 0.4.0

Collecteur Android personnel et lecteur dans le même programme. Cette mise à jour ajoute un onglet **Diagnostic**, les noms TLS visibles, des relevés de disponibilité Internet et des exports récupérables. Elle conserve l’analyse automatique et la réduction du bruit de la version 0.3. Les événements reçus restent enregistrés dans la base privée du téléphone. Les permissions et la clé de signature sont inchangées; le module natif est reconstruit pour ajouter l’observation du premier ClientHello TLS.

## Essai sur le téléphone

1. Installer `journal-local.apk` comme **mise à jour**, sans désinstaller l’application. Ouvrir Journal local, toucher **Démarrer**, puis **Activer connexions apps** si la capture VPN est arrêtée.
2. Ouvrir une application connectée, puis revenir dans **Journal**. Les nouvelles connexions TLS/TCP peuvent produire **Nom TLS observé**. Les anciennes lignes ne sont pas enrichies rétroactivement et tous les flux ne livrent pas un nom.
3. Dans **Diagnostic**, essayer **Exporter en JSONL** en laissant la collecte active. **Réenregistrer le dernier instantané** permet de retenter la copie d’un export préparé.
4. Pour un ancien export endommagé, choisir **Récupérer un JSON / JSONL**, puis **Enregistrer la copie récupérée**. La copie reste séparée du journal en cours.
5. Si un diagnostic Android est disponible sur le téléphone, régler son année/fuseau dans **Diagnostic**, puis l’importer. Ouvrir ensuite un flux dans **Journal → Croiser avec le diagnostic**. Le résultat peut être exporté séparément.

Un ordinateur n’est pas nécessaire pour ces commandes. L’application n’obtient pas automatiquement le logcat des autres processus. Sur les appareils qui proposent cette fonction, un rapport peut être créé dans **Options de développement → Créer un rapport de bug**, puis enregistré dans les fichiers du téléphone. Le rapport peut avoir perdu les lignes anciennes et ne contient pas nécessairement le propriétaire de chaque socket.

## Attribution et rapprochement

L’API Android fournit un UID, pas un PID. Pour l’UID 1000, `cross_analysis` laisse explicitement le processus, le paquet précis et le service indéterminés, même si Android ne retourne qu’un seul paquet visible. La liste des paquets peut être limitée par leur visibilité; elle ne désigne pas l’initiateur du flux.

L’import accepte du logcat texte, un `bugreport*.txt` dans un ZIP, ou le format de socket ci-dessous. Il indexe l’heure, les PID/TID, l’UID s’il est présent, le tag et au plus huit mentions d’IP:port par ligne. Les messages bruts ne sont pas conservés. Le tag logcat n’est jamais assimilé à un paquet. Le PID d’une ligne est celui de son émetteur, qui peut seulement rapporter l’activité d’un autre processus.

La comparaison porte sur le **début observé du flux**, dans une fenêtre réglable de ±1 à ±60 secondes (±2 par défaut). Au plus 200 lignes les plus proches sont examinées, puis 20 candidates sont affichées avec les comptes et références d’origine. Une recherche bornée peut manquer une ligne pertinente dans un diagnostic très dense.

| Niveau affiché | Critères | Portée |
| --- | --- | --- |
| Heure proche seulement | Horodatage dans la fenêtre | Coïncidence temporelle, sans preuve de propriété du socket. |
| Destination mentionnée à proximité | Heure et même IP/port distant dans une ligne | Indice plus précis; le PID reste celui de l’émetteur du message. |
| Même socket et UID rapportés | Heure, protocole, deux IP, deux ports et UID identiques dans une preuve structurée | Propriété rapportée par le fichier choisi; sa provenance et l’appareil ne sont pas authentifiés. |

Le rapprochement ne confirme automatiquement aucun paquet ni service. Même un PID exact peut héberger plusieurs services. La colonne de provenance, les hypothèses d’horloge et les champs `package_attribution_confirmed` / `service_attribution_confirmed` rendent cette limite explicite.

Le logcat au format epoch est traité en UTC. Les lignes avec date civile utilisent le décalage UTC choisi à l’import, et les lignes sans année utilisent aussi l’année choisie. Ces hypothèses sont enregistrées; modifier les réglages ne change pas les diagnostics déjà indexés. Un décalage fixe ne résout pas automatiquement un changement d’heure saisonnier dans un fichier couvrant plusieurs périodes.

Format facultatif pour une source externe qui a réellement relevé un propriétaire de socket, **exemple fictif** (une ligne JSON par observation) :

```json
{"schema":"journal-socket-evidence/1","timestamp_ms":1767225600123,"pid":321,"uid":1000,"protocol":"TCP","local_ip":"10.0.0.2","local_port":45678,"remote_ip":"203.0.113.10","remote_port":443,"process_name":"processus.exemple","source":"outil et méthode de mesure à préciser"}
```

Le collecteur ne fabrique pas ces preuves à partir d’un simple logcat. Les imports sont limités à 64 Mio de texte, 500 000 lignes, 200 000 lignes reconnues et 16 Kio par ligne. La lecture d’un ZIP s’arrête au premier `bugreport*.txt` parmi 100 entrées, avec une limite de 64 Mio de données sautées avant ce membre. Aucun chemin du ZIP n’est extrait sur disque. L’index `diagnostics.sqlite` est séparé des événements VPN; l’import est transactionnel.

## Coupures, TLS et contexte de sécurité

**La collecte locale fonctionne sans Internet tant que son processus fonctionne et que le stockage le permet.** Les signaux de vie continuent donc à aider à distinguer une absence d’Internet d’une interruption de collecte. Les nouveaux relevés contiennent les réseaux physiques visibles, leur validation Internet par Android, le réseau par défaut, l’état du VPN et ses erreurs. Aucun test réseau actif n’est envoyé par ce diagnostic.

Les transitions **Internet non validé par Android** et **Internet de nouveau validé par Android** donnent une durée entre observations. Ce n’est pas une mesure exacte d’une panne continue ni une preuve de sa cause. Les lacunes de plus de 150 secondes et les écarts entre horloge civile et monotone sont signalés. Les seules captures d’écran et descriptions reçues ne permettent pas de reconstruire les 16 minutes rapportées avant la version VPN.

Le nom SNI du premier ClientHello TLS sur TCP est lu passivement lorsque visible, dans une limite de 32 Kio par flux. Le réassemblage prend en compte les fragments TCP, répétitions et arrivées désordonnées dans cette limite. Les données utilisées temporairement pour cette lecture ne sont pas enregistrées comme contenu. QUIC/UDP, les sessions commencées avant la capture et le TLS chiffré ne sont pas décodés.

Une extension ECH peut aussi être du GREASE : **Nom TLS externe possible (ECH/GREASE)** n’affirme ni l’usage accepté d’ECH ni la destination interne. Ce nom externe est exclu des règles de surveillance des domaines. Un SNI ordinaire est un nom annoncé par le client, pas une preuve du contenu ou de l’origine des données reçues. Références : [SNI, RFC 6066](https://www.rfc-editor.org/rfc/rfc6066) et [ECH, RFC 9849](https://www.rfc-editor.org/rfc/rfc9849.html).

`security_context` ajoute un contexte bibliographique local pour DiagMonAgent lorsqu’il figure parmi les candidats. **CVE-2025-20912** concerne le produit **Android Watch 14** avant **SMR Mar-2025 Release 1** dans le [bulletin Samsung de mars 2025](https://security.samsungmobile.com/securityUpdate.smsb?year=2025&month=03). Un téléphone Android 16 n’est pas classé vulnérable sur cette seule base. La version visible du paquet et le niveau de correctif sont conservés comme contexte. Ce catalogue contient cette entrée; il n’est ni exhaustif ni mis à jour automatiquement. Une CVE n’attribue pas un flux à un paquet.

Références Android : [propriétaire UID d’une connexion](https://developer.android.com/reference/android/net/ConnectivityManager#getConnectionOwnerUid(int,%20java.net.InetSocketAddress,%20java.net.InetSocketAddress)) et [journalisation et accès aux logs](https://source.android.com/docs/core/tests/debug/understanding-logging).

## Intégrité et récupération

L’export fixe ensemble le dernier identifiant et le nombre de lignes à exporter, puis parcourt cet instantané par pages. Les nouveaux événements peuvent continuer d’arriver et ne sont pas ajoutés au milieu de cet export. L’ancienne version fixait déjà un dernier identifiant : laisser la collecte active ne suffit donc pas à expliquer un JSON tronqué. Sans le fichier et la trace de l’export, sa cause reste inconnue.

Un fichier complet est d’abord préparé et synchronisé dans le cache privé, puis copié vers le document choisi. La copie est relue et comparée en taille et SHA-256 lorsque le fournisseur de fichiers le permet. Une relecture impossible est annoncée séparément; une copie interrompue peut encore laisser une destination incomplète. Le dernier instantané complet permet de retenter la sauvegarde tant que le cache existe. Les fichiers de cache de plus de sept jours peuvent être supprimés; ils ne remplacent pas une sauvegarde choisie par l’utilisateur.

Les formats JSON et JSONL portent le schéma `journal-cellulaire/2`, le plafond d’identifiants, le nombre attendu, puis un bilan final avec `complete`, `event_count`, `last_id` et `sha256_events`. Le hash couvre les octets UTF-8 de chaque objet événement suivi de LF, sans les séparateurs du tableau. C’est un contrôle de cohérence, **pas une signature numérique ni une authentification du téléphone**.

La récupération valide la syntaxe strictement. Dans un tableau JSON, elle conserve uniquement le préfixe d’événements complets jusqu’à la première erreur. En JSONL, les lignes complètes et valides peuvent être récupérées séparément. Le bilan distingue source complète, incomplète, intégrité absente ou incohérente. Il conserve le SHA-256 du fichier source et le nombre d’événements sauvés; aucune fin manquante n’est inventée. Limites : source de 128 Mio, objet de 1 Mio et profondeur de 64 niveaux. L’original est lu uniquement et la copie n’est pas injectée dans la collecte actuelle.

## Anomalies, enquête et bruit

Après la mise à jour, ouvrir **Journal local → Anomalies**. L’analyse parcourt automatiquement l’historique local par lots, puis les nouveaux événements, y compris quand le lecteur est fermé si le processus de collecte fonctionne. Le compteur indique les événements examinés et l’analyse en cours. Elle ne reconstitue pas une activité qui n’a pas été collectée. Cette version n’a pas accès aux journaux du téléphone depuis ChatGPT et n’y envoie rien.

Choisir **Anomalies et diagnostics** ou **Traces de l’enquête**. Toucher un groupe pour lire la règle, les valeurs et un échantillon d’événements sources (12 références maximum). Les faits chiffrés sont ceux du dernier déclenchement du groupe; les occurrences comptent les déclenchements, pas des incidents distincts. **Marquer vu** marque tout ce groupe, y compris ses répétitions ultérieures; un nouveau groupe reste à lire. Le filtre **À lire uniquement** et le compteur d’onglet permettent de retrouver les nouveaux signalements.

| Règle | Réglage de départ / donnée utilisée | Ce que le constat n’établit pas |
| --- | --- | --- |
| Échecs répétés | 8 flux distincts fermés en erreur, même app/UID non partagé et destination, en 5 minutes | Une attaque; le réseau, le serveur ou le relais peuvent être en cause. Réinitialisations de démarrage sans erreur et fermetures normales exclues. |
| Volume envoyé | 10 Mio en 5 minutes d’observation, par app/UID non partagé | Une fuite; pièces jointes, sauvegardes et vidéos peuvent dépasser ce seuil. |
| DNS modifié | Deux ensembles de résolveurs différents, même réseau et même session de collecte | Une modification malveillante; initialisation, ordre des adresses et nouveau réseau exclus. |
| Collecte à vérifier | Erreurs explicites, limites du relais ou signal de vie espacé de plus de 150 secondes | Une intrusion; certaines lacunes n’ont aucune trace lorsque le processus est arrêté. |
| Domaines personnels | Liste vide, à remplir dans **Règles et seuils** | Une liste de domaines malveillants. La règle signale seulement les noms choisis par l’utilisateur. |

Les seuils sont des choix de départ ajustables, pas des normes de sécurité. Il n’y a pas de modèle apprenant ni de score de danger. Les inconnus et UID partagés ne sont pas réunis dans une application fictive. Le nombre de relevés exclus faute d’attribution ou d’intervalle exploitable est indiqué.

Les compteurs d’un même flux sont cumulatifs : seules leurs augmentations sont additionnées. Le premier compteur sans ouverture/baseline, les baisses de compteur et les intervalles supérieurs à cinq minutes ne sont pas transformés en pics de trafic. Les fenêtres utilisent l’horloge monotone, des buckets d’une seconde et le moment du relevé : elles ne prétendent pas dater chaque octet. Les états sont réinitialisés lors d’un nouveau démarrage de collecte ou d’un recul significatif de l’horloge monotone. Les regroupements suivent des périodes fixes de 5 minutes pour les seuils, 15 minutes pour les autres règles; la mesure des seuils reste glissante. Des groupes successifs peuvent donc décrire la même activité persistante.

Dans **Règles et seuils**, activer/désactiver les règles, ajuster les seuils et ajouter des domaines. Une correspondance exige le domaine exact ou un vrai sous-domaine, avec normalisation de casse/IDNA; pas de joker ni de simple sous-chaîne. Les réglages s’appliquent aux événements encore à analyser et aux futurs événements. Ils ne reclassent pas les anciens signalements. Les fenêtres de seuil sont remises à zéro lors de ce changement et les nouveaux groupes conservent leur version de réglage.

**Réduire le bruit** masque les signaux de vie, les compteurs globaux et les états de batterie dans la chronologie. **Tout afficher** les rétablit. Une recherche textuelle consulte toutes les lignes, même avec la vue allégée. Les événements, leurs heures, les répétitions et les exports du journal restent intacts. Le choix d’affichage est mémorisé avec **Enregistrer les règles**. Les destinations des flux sont maintenant préfixées **Destination contactée**; les détails distinguent la base privée du téléphone d’un fichier importé.

## Ce que recherche le rapport fourni

Le rapport copié dans la conversation est une liste de pistes fournie par l’utilisateur, pas une validation de l’activité de son téléphone. L’application ne certifie pas les chaînes GitHub de ce rapport et ne déduit pas l’exécution d’un code à partir de sa présence dans un dépôt.

| Piste | Recherche réalisable dans le collecteur actuel | Interprétation affichée |
| --- | --- | --- |
| c2s.ic.gov, sc2s.sgov.gov, api.aws.ic.gov, api.aws.scloud | Nom exact et vrais sous-domaines dans le DNS UDP en clair ou le SNI visible sans ECH/GREASE | Correspondance avec le rapport, pas une connexion réussie ni une destination effective des prompts. |
| bedrock-runtime-fips | Noms de forme `bedrock-runtime-fips.<région>.amazonaws.com` ou `.com.cn` | Correspondance de nom uniquement. |
| OTLP | Ports distants 4317/4318 des flux enregistrés, une fois par flux | Indice de port, protocole et contenu non confirmés. Le port 443 seul ne déclenche pas cette règle. |
| X-OpenAI-Fedramp, claim JWT, /wham/config/bundle, /api/codex/config/bundle | Non collectés | En-têtes, jetons et chemins HTTP ne sont pas conservés par ce collecteur. |
| log_user_prompt, codex.user_prompt, policy_decision, NetworkProxyAuditMetadata, allowed-tools, LoadSkill | Non collectés | Options, événements internes, corps de requêtes ou code exécuté. |
| grantRuntimePermission, setPermissionGrantState, obfuscate, exported_symbols, generate_native_sdk, perlasm, TARGET_OBJECTS, RNG, AES, IRK, fipsmodule, ring, aws-lc-rs, rustls | Non collectés | Symboles de code, opérations internes ou crypto; aucune chaîne d’identité déduite d’un trafic IP. |

Les ports par défaut OTLP sont documentés dans la [spécification officielle OpenTelemetry](https://opentelemetry.io/docs/specs/otlp/#otlpgrpc-default-port) pour gRPC et dans sa [section HTTP](https://opentelemetry.io/docs/specs/otlp/#otlphttp-default-port). D’autres protocoles peuvent utiliser ces ports et OTLP peut utiliser d’autres ports. Ces critères ne reconnaissent ni le contenu OTLP ni une provenance OpenAI.

`example.com/otel` est exclu : le rapport le présente comme exemple documentaire. Aucun WHOIS, DNS externe, service de réputation, blocage, déchiffrement TLS, certificat ou privilège supplémentaire n’est ajouté. Les recherches examinent uniquement les événements déjà produits par le collecteur. DNS chiffré, cache, IP directe ou absence de capture peuvent empêcher un résultat; aucun résultat ne veut pas dire qu’une fonction n’existe pas ou n’a pas été utilisée.

**Exporter l’analyse** sauvegarde les groupes, leurs critères, réglages et références dans un JSON distinct. **Exporter** dans le journal conserve tous les événements originaux. Les deux exports sont manuels vers la destination choisie avec Android.

## Installer et consulter

1. Ouvrir `journal-local.apk` sur le téléphone et accepter la **mise à jour**. Ne pas désinstaller l’ancienne version : même paquet, même clé de signature et même base SQLite. Les lignes déjà enregistrées sont conservées.
2. Ouvrir **Journal local → Activer connexions apps**, puis accepter la demande VPN d’Android. Cette activation remplace un autre VPN actif dans le même profil.
3. Ouvrir ChatGPT, envoyer un message et revenir au journal. Dans **Afficher**, choisir **Connexions des applications**, puis **ChatGPT** dans les acteurs si Android a fourni ce nom. Toucher une ligne pour voir IP, port, protocole, volumes et attribution.

Le relais publie un relevé environ toutes les cinq secondes pour les flux dont les compteurs changent, ainsi qu’à l’ouverture et la fermeture. Le lecteur se rafraîchit toutes les trois secondes quand il est visible, sauf pendant la consultation d’un détail. Une même connexion peut porter plusieurs messages : le journal montre son trafic, sans délimiter chaque message ni lire son contenu chiffré. Les volumes incluent les en-têtes IP et transport.

Si Android ne fournit pas le propriétaire d’un flux, la ligne indique **Application non identifiée**, un **UID**, ou un **UID partagé**. Aucun nom d’app n’est déduit d’une IP. Un relevé ultérieur peut obtenir une attribution sans modifier les anciennes lignes.

**Arrêter les connexions apps** arrête le VPN; **Tout arrêter** arrête aussi les états système. Les événements restent consultables. Si une app ne se connecte plus après l’activation, arrêter les connexions apps pour retirer le VPN, puis consulter l’erreur dans **Sources**.

**Démarrer** active séparément les états système. Le Bluetooth reste facultatif dans **Sources → Activer le suivi Bluetooth**, avec la permission Appareils à proximité. Il ne lance pas de recherche de périphériques et n’enregistre aucun son.

## Couverture

| Source | Informations | Limites |
| --- | --- | --- |
| VPN local | TCP/UDP IPv4 et IPv6, IP, port, volumes, ouverture, mises à jour et fermeture | Trafic routé vers le VPN uniquement; aucun déchiffrement TLS. Les échos ICMP partiellement pris en charge par la bibliothèque ne sont pas validés par les essais réseau. |
| Identification Android | UID, paquet et libellé quand disponibles | API 29+, TCP/UDP, VPN actif. Attribution parfois inconnue ou partagée. |
| DNS visible | Première question d’une requête DNS UDP en clair et son type | DNS chiffré et DNS sur TCP non analysés. Pas d’attribution automatique du domaine à d’autres flux. |
| TLS visible | Nom annoncé dans le premier ClientHello TCP; statut de lecture et extension ECH éventuelle | Limite de 32 Kio, aucun déchiffrement, pas de QUIC; un nom externe ECH/GREASE n’identifie pas la destination interne. |
| Réseau physique du relais | Wi-Fi, cellulaire, Ethernet ou Bluetooth selon Android | LTE/5G non déterminé; une reconfiguration interrompt la capture et les flux existants. |
| État réseau système | Disponibilité, perte, propriétés, résolveurs fournis par Android | État global, distinct d’une requête Internet par application. |
| Diagnostic importé | Horodatages, PID/TID, UID disponible, mentions de destination et références de ligne | Import local choisi; aucune capture automatique du logcat système ni garantie d’attribution. |
| Compteurs globaux | Octets depuis le démarrage, environ chaque minute | Lecture par Journal local; pas une nouvelle connexion ni une vérification de sécurité. |
| OS et matériel | Batterie, alimentation, écran, utilisateur présent, heure/fuseau, stockage, USB hôte | Notifications reçues pendant la collecte; pas toutes les opérations du système ou des apps. |
| Bluetooth facultatif | Liens connectés/déconnectés, appairage, état de l’adaptateur | Pas de capture radio ou de contenu audio. |
| Collecteur | Début, arrêt, erreurs, reconfiguration, signal de vie système, certaines lacunes | Ne reconstitue pas les événements manqués quand le processus ne fonctionne pas. |

Les clients d’un partage de connexion, les autres profils Android, les opérations internes des apps et les serveurs distants ne sont pas couverts intégralement. Journal local est exclu de son propre VPN pour éviter les boucles; son trafic ne passe donc pas par cette mesure. Les fragments IP, extensions IPv6 et protocoles non pris en charge sont ignorés et comptabilisés dans des diagnostics. Aucun contenu de paquet ou fichier PCAP n’est conservé.

Un serveur météo peut apparaître si l’app s’y connecte pendant la capture. Son adresse seule ne prouve pas l’origine des prévisions : il faut également les crédits de l’app et les traces disponibles. Les permissions Bixby affichées proviennent des captures fournies, sans preuve d’utilisation ni droits conférés à Journal local. Une interaction n’est pas automatiquement une infraction.

## Permissions et fonctionnement local

La version 0.2 ajoute **INTERNET**, nécessaire pour relayer les connexions vers leurs destinations originales. Aucun serveur VPN distant, compte, service d’analyse externe ou téléversement automatique du journal n’est configuré. Ce VPN local ne fournit pas d’anonymisation; il conserve le chiffrement mis en place par les apps.

Les autres permissions sont l’état réseau, le service au premier plan avec usage spécial, ses notifications et le Bluetooth facultatif. Aucune permission microphone, caméra, contacts, SMS, localisation ou accessibilité. Aucun root ni certificat d’interception. `BIND_VPN_SERVICE` protège le service pour que le système Android puisse s’y lier.

Le WebView charge seulement le lecteur embarqué. Accès réseau, navigation externe, accès aux fichiers/contenus Android, fenêtres externes et permissions multimédias sont bloqués. Le pont expose seulement les commandes locales prévues. Ouvrir le lecteur ne démarre pas le VPN et ne transmet rien à ChatGPT.

## Durée et conservation

Fermer le lecteur laisse les services activés fonctionner tant qu’Android le permet. **L’enregistrement n’est pas garanti à l’infini.** Après redémarrage, arrêt forcé, révocation VPN ou arrêt de la capture réseau, il faut rouvrir Journal local et la réactiver. Le VPN ne prend pas en charge le mode permanent d’Android et ne redémarre pas automatiquement après la fin de son processus. Une interruption brutale peut ne laisser aucune ligne d’arrêt.

Une reconfiguration ferme les flux puis recrée l’interface avec les résolveurs DNS du réseau physique; aucun résolveur public n’est imposé. Chaque socket est protégée contre les boucles VPN et reliée au réseau physique choisi. Les connexions TCP antérieures à l’activation reçoivent une réinitialisation pour permettre aux apps de se reconnecter : une session TLS ne peut pas être reprise au milieu par le relais.

Limite de 512 sockets : à saturation, les plus anciennes sont fermées pour revenir à 480 et un diagnostic est enregistré. Expiration après 7 200 secondes d’inactivité TCP ou 180 secondes UDP. Ces limites et les changements de réseau peuvent interrompre des connexions.

La base `journal.sqlite` conserve le schéma version 1 et ajoute les événements sans suppression automatique. Les compteurs d’un flux sont cumulatifs : ne pas additionner ses différents relevés. À épuisement du stockage, l’erreur est affichée et le service concerné s’arrête; la trace de l’erreur peut elle-même manquer.

L’analyse utilise une autre base privée, `analysis.sqlite`, schéma 1. Chaque lot enregistre ensemble son état, son point de reprise et ses signalements dans une transaction. Une reprise ne compte donc pas de nouveau les événements déjà validés. Un échec d’analyse s’affiche séparément et ne transforme pas une écriture réussie du journal en échec de collecte. L’état sérialisé n’est lu que depuis cette base privée, jamais depuis un import. Les états transitoires expirent et sont bornés; une baseline manquante ne produit pas de volume inventé. Les événements et les signalements persistants n’ont pas de suppression automatique.

**Exporter** crée une copie JSON dans la destination choisie avec Android. Cet export facultatif parcourt le journal par pages bornées. Désinstaller ou effacer les données de l’app supprime sa base; une mise à jour avec la même clé la conserve.

## Sources, licence et reconstruction

- `app/src/main/java/fr/erick/journallocal/` : VPN, attribution, états système, SQLite et lecteur.
- `app/src/main/cpp/relay.c`, `jni.c`, `relay.h`, `tls_sni.c`, `tls_sni.h` : relais IP, métadonnées, observation TLS et pont natif.
- `tools/` : lecteur, filtres et génération du HTML embarqué.
- `AnomalyRules.java` : règles sans dépendance Android; `AnomalyMonitor.java` : traitement local et transactions. `tools/analysis-*` : interface de l’analyse.
- `DiagnosticParser.java`, `DiagnosticStore.java`, `tools/diagnostic-*` : import et rapprochement avec portée explicite. `NetworkHealth.java` et `SecurityContext.java` : disponibilité et contexte documenté.
- `SnapshotExporter.java`, `ExportFiles.java`, `JournalRecovery.java`, `JsonSyntax.java` : instantanés, vérification, récupération et syntaxe stricte.
- `third_party/zdtun/` : source complète du relais, provenance, changements et licences.
- `tests/` : essais réseau, interface et vérification du paquet.

[zdtun](https://github.com/emanuele-f/zdtun), Copyright 2018-2021 Emanuele Faranda, LGPL v3 ou ultérieure, révision `80b7941d4e685d8354346820878eaec0e35b6b1e`, est lié dynamiquement dans `libjournal_zdtun.so`. `UPSTREAM.json` donne la provenance et le hash de l’archive; `JOURNAL-CHANGES.txt` documente les quatre changements de limites. Les licences LGPL et GPL complètes sont incluses et accessibles dans **Sources et licences**. Les fonctions utilitaires de commande non utilisées ne sont pas liées dans l’APK.

Construire sous Linux avec Java 17, Python 3, Android Platform 35 révision 2, Build Tools 35.0.0, ECJ 3.40.0 et NDK r27d (27.3.13750724). Min API 26, cible 35, ABI `arm64-v8a` et `x86_64`, segments ELF alignés sur 16 Kio. `build.py` ne télécharge aucune dépendance.

```bash
python3 build.py \
  --android-jar /chemin/SDK/platforms/android-35/android.jar \
  --build-tools /chemin/SDK/build-tools/35.0.0 \
  --ecj /chemin/ecj-3.40.0.jar \
  --ndk /chemin/SDK/ndk/27.3.13750724 \
  --signing-dir /chemin/prive/journal-local-signing
```

Garder `journal-local.p12` et `password.txt` hors des sources. La sauvegarde privée remise précédemment contient la clé d’origine, nécessaire aux mises à jour. Sans cette clé, le script en crée une nouvelle qui ne permet pas de remplacer la version installée. Pour installer une variante avec une autre clé en conservant l’app initiale, choisir un nom de paquet distinct. Adapter si besoin le chemin `keytool` Java 17 dans le script.

La version 0.4 modifie le code natif : **la reconstruction avec le NDK est nécessaire**. Le mode historique `--reuse-native-apk` reste volontairement verrouillé par les hashes de la version 0.2 et rejette ces sources modifiées. La bibliothèque tierce `libjournal_zdtun.so` livrée reste identique à celle de la version 0.2; `libjournalrelay.so` intègre le nouvel observateur TLS.

## Validation

```bash
python3 tests/test_relay.py
NODE_PATH=/chemin/outils/node_modules node tests/native-reader.cjs
python3 tests/verify_package.py \
  --build-tools /chemin/SDK/build-tools/35.0.0 \
  --old-apk /chemin/journal-local-0.2.apk
```

Les sept tests réseau utilisent GCC, OpenSSL et Python, avec de vrais serveurs TCP/UDP/TLS en boucle locale et une interface TUN simulée. Ils vérifient IPv4/IPv6, l’intégrité des octets, une session TLS avec certificat vérifié et échanges espacés, DNS, paquets malformés, réinitialisation des connexions antérieures et arrêt propre. Ils vérifient aussi le SNI réellement observé dans la session de test, le réassemblage et les limites du parseur TLS.

Le lecteur utilise jsdom 26.1.0 et un pont Android simulé pour tester activation explicite, mises à jour, filtres, pagination, détails, export, Bluetooth, texte non interprété en HTML et reprise après erreur. Ces outils ne sont pas embarqués. Le paquet est contrôlé pour sa signature d’origine, ses permissions, ses contrats JNI, ses bibliothèques, son alignement et ses ressources embarquées.

Le test du lecteur couvre aussi les vues anomalies/traces, le filtre de bruit, la recherche sur toutes les lignes, les sources, « Marquer vu », les réglages et leur conservation pendant la lecture. Le moteur possède des essais déterministes sur des données fictives, exécutables sans dépendance Java externe :

```bash
java -jar /chemin/ecj.jar -encoding UTF-8 -source 1.8 -target 1.8 \
  -d build/host-rules app/src/main/java/fr/erick/journallocal/AnomalyRules.java tests/AnomalyRulesTest.java
java -cp build/host-rules fr.erick.journallocal.AnomalyRulesTest
```

Ces tests couvrent les deltas, doublons, fenêtres, changements d’horloge/session, reprise de l’état, DNS initial/réordonné, frontières de domaines, ports, erreurs de collecte et exclusions d’attribution. Ils ne sont pas une mesure de précision sur un trafic réel ni un test des transactions SQLite dans Android.

La version 0.4 ajoute les exclusions UID 1000 et ECH/GREASE et la surveillance SNI, pour **44 vérifications de comportement**. Le lecteur teste aussi l’onglet Diagnostic, les paramètres d’horloge, les commandes d’import/récupération, les indices et l’export d’un rapprochement, avec texte non interprété comme HTML.

```bash
python3 tests/run-diagnostics.py \
  --ecj /chemin/ecj-3.40.0.jar \
  --json-jar /chemin/json-20250517.jar
```

Ce dernier test emploie [JSON-java 20250517](https://github.com/stleary/JSON-java/releases/tag/20250517) uniquement sur l’hôte; cette dépendance n’est pas embarquée. Ses **4 537 vérifications** couvrent les points de troncature d’un export fictif, les ajouts concurrents après fixation de l’instantané, les erreurs d’écriture, les empreintes altérées, la récupération stricte, les formats d’horloge et les correspondances UID/PID/tuple. Le nombre est celui de cette suite déterministe; il ne représente pas 4 537 scénarios Android indépendants.

**Aucun test Android, émulateur ou Samsung n’a été réalisé ici.** L’autorisation VPN, l’attribution réelle des UID, le maintien en arrière-plan, le DNS privé, les changements Wi-Fi/cellulaire, les transactions SQLite et la copie via les fournisseurs de fichiers Android restent à confirmer sur le téléphone. `verification.json` distingue ces limites des vérifications effectuées.

Références officielles : [VPN Android](https://developer.android.com/develop/connectivity/vpn) et [identification du propriétaire d’une connexion](https://developer.android.com/reference/android/net/ConnectivityManager#getConnectionOwnerUid(int,%20java.net.InetSocketAddress,%20java.net.InetSocketAddress)).
