  const nativeBridge=window.JournalAndroid||null;
  let nativeAnchor=0, nativeActorList="";
  function nativeStatus(){const status=JSON.parse(nativeBridge.status());if(status.error)message(status.error,true);return status;}
  function renderNativeSources(){
    if(!nativeBridge)return;const status=nativeStatus(),pane=$('jc-pane-sources');pane.replaceChildren();pane.append(element('h3','Collecte sur ce téléphone'));
    const sources=[['Connexions des applications',status.capture?status.capture_state:status.capture_starting?status.capture_state:'Capture non active. Active le VPN local depuis le journal.'],['Écran, alimentation, batterie, USB hôte',status.running?'Service actif : notifications système accessibles.':'Service arrêté.'],['Réseau par défaut',status.network?'Changements Wi-Fi / cellulaire / VPN et configuration DNS.':'Source non active.'],['Bluetooth',status.bluetooth?'Connexions et appairages : suivi activé.':'Suivi optionnel non actif.'],['Stockage','Tous les événements reçus sont enregistrés dans la base privée du téléphone. Aucune suppression automatique.'],['Limites','VPN local : IP, port, protocole et volumes; application si Android l’identifie. Messages chiffrés non lus. Questions DNS UDP en clair et noms SNI du premier ClientHello TLS/TCP quand visibles; limites de 32 Kio, ECH et QUIC explicites. UID partagé : processus précis non identifié automatiquement. Pas d’accès aux opérations internes des apps, aux trames Bluetooth ou garanti aux appareils partagés.'],['Affichage ici / dans ChatGPT','Le lecteur local est branché à la base. Aucune transmission en direct vers la conversation.']];
    for(const [label,value]of sources){const row=element('div',undefined,'jc-source');row.append(element('strong',label),element('span',value,'jc-sub'));pane.append(row);}
    const bluetooth=element('button',status.bluetooth_enabled?'Désactiver le suivi Bluetooth':'Activer le suivi Bluetooth');bluetooth.id='jc-bluetooth-native';bluetooth.type='button';bluetooth.onclick=()=>{nativeBridge.command(status.bluetooth_enabled?'bluetooth-off':'bluetooth-on');setTimeout(renderNativeSources,1200);};pane.append(bluetooth);
    const last=element('p',status.last_alive_ms?'Dernier signal de vie : '+new Date(status.last_alive_ms).toISOString():'Aucun signal de vie dans cette session.','jc-sub');last.style.marginTop='14px';pane.append(last);
    const permissions=element('details');permissions.append(element('summary','Permissions de ce collecteur'),element('p','État du réseau; service au premier plan; affichage de sa notification; Bluetooth uniquement si tu actives ce suivi. La permission Internet relaie les connexions vers leur destination originale. La version 0.4 ne demande aucune permission supplémentaire; les diagnostics sont choisis avec le sélecteur de fichiers Android. Le VPN local demande ton accord Android et remplace tout autre VPN actif dans ce profil. Aucun serveur VPN distant ni envoi du journal. Aucune permission microphone, caméra, contacts, SMS, localisation ou accessibilité.'));pane.append(permissions);const licenses=element('button','Sources et licences');licenses.type='button';licenses.onclick=()=>nativeBridge.command('licenses');pane.append(licenses);if(status.capture_error)pane.append(element('p',status.capture_error,'jc-error'));
  }
  function renderNative(){
    try{
      const status=nativeStatus();root.querySelector('.jc-state .jc-label').textContent=status.capture?'Connexions des applications actives':status.capture_starting?status.capture_state:status.running?'États système actifs · connexions des apps non capturées':'Collecte arrêtée sur ce téléphone';
      $('jc-start-native').disabled=status.running;$('jc-stop-native').disabled=!status.running&&!status.capture&&!status.capture_starting;
      $('jc-capture-native').textContent=status.capture||status.capture_starting?'Arrêter les connexions apps':'Activer connexions apps';
      $('jc-capture-note').textContent=status.capture_error||'Le VPN local observe les connexions, sans lire les messages chiffrés ni envoyer le journal. Il remplace tout autre VPN actif. Tu peux l’arrêter ici à tout moment.';
      const result=JSON.parse(nativeBridge.page($('jc-search').value,$('jc-transport').value,state.page*PAGE_SIZE,PAGE_SIZE,state.page?nativeAnchor:0,$('jc-app').value,$('jc-kind').value,$('jc-quiet').value==='quiet'));
      if(result.error)throw new Error(result.error);if(!status.error)$('jc-error').hidden=true;if(state.page&&!result.events.length){state.page=0;nativeAnchor=0;renderNative();return;}
      nativeAnchor=result.ceiling_id;
      const actors=JSON.stringify(result.actors||[]);if(actors!==nativeActorList){nativeActorList=actors;fillSelect('jc-app',result.actors||[],'Tous les acteurs');}
      state.sources=[{id:'phone',name:'Journal local · base privée du téléphone'}];
      state.events=result.events.map((raw,index)=>{const event=normalize(raw,index,'phone');event.key='phone:'+raw.id;event.transport=raw.transport||'Inconnu';return event;});
      $('jc-total').textContent=result.total+' événements enregistrés';$('jc-export').disabled=!result.total;$('jc-filter-area').hidden=!result.total;
      $('jc-filter-count').textContent=result.matched+' résultats / '+result.total+' enregistrés'+(result.hidden_count?' · '+result.hidden_count+' lignes répétitives masquées':'');
      renderRows(state.events);renderDetail();
      const empty=$('jc-empty');empty.hidden=Boolean(result.events.length);
      if(!result.total){empty.querySelector('h3').textContent=status.running?'En attente des premiers événements':'Ton collecteur est prêt';empty.querySelector('p').textContent='Active les connexions apps, utilise une application Internet, puis reviens ici. Démarrer active aussi les états système; les événements reçus s’ajoutent automatiquement.';}
      else if(!result.events.length){empty.querySelector('h3').textContent='Aucun événement pour ces filtres';empty.querySelector('p').textContent='Les événements restent enregistrés. Modifie la recherche pour les retrouver.';}
      $('jc-see-bixby').hidden=true;
      const pages=Math.max(1,Math.ceil(result.matched/PAGE_SIZE));$('jc-pagination').hidden=pages<=1;$('jc-page').textContent='Page '+(state.page+1)+' / '+pages;$('jc-prev').disabled=!state.page;$('jc-next').disabled=state.page>=pages-1;
    }catch(error){message(error.message||'Lecture automatique indisponible.',true);}
  }
  if(nativeBridge){
    root.querySelector('.jc-top p').textContent='Les événements reçus sur ce téléphone.';
    $('jc-events').setAttribute('aria-label','Événements enregistrés automatiquement');
    $('jc-import-toggle').hidden=true;$('jc-import-form').hidden=true;
    $('jc-app').parentElement.hidden=false;$('jc-order').parentElement.hidden=true;
    fillSelect('jc-transport',['Wi-Fi','Cellulaire','Bluetooth','USB','Ethernet','VPN','Interne','Global','Inconnu','Autre'],'Toutes les connexions');
    const actions=$('jc-export').parentElement;
    const start=element('button','Démarrer','jc-primary');start.id='jc-start-native';start.type='button';start.onclick=()=>{nativeBridge.command('start');setTimeout(renderNative,1200);};
    const stop=element('button','Tout arrêter');stop.id='jc-stop-native';stop.type='button';stop.onclick=()=>{nativeBridge.command('stop');setTimeout(renderNative,1200);};const capture=element('button','Activer connexions apps','jc-primary');capture.id='jc-capture-native';capture.type='button';capture.onclick=()=>{const status=nativeStatus();nativeBridge.command(status.capture||status.capture_starting?'capture-off':'capture-on');setTimeout(renderNative,1200);};actions.prepend(start,capture,stop);
    const note=element('p',undefined,'jc-sub');note.id='jc-capture-note';$('jc-message').before(note);
    const kind=element('select');kind.id='jc-kind';kind.append(new Option('Tout le journal',''),new Option('Connexions des applications','apps'),new Option('Système et collecteur','system'));
    const kindLabel=element('label','Afficher');kindLabel.append(kind);$('jc-app').parentElement.before(kindLabel);
    kind.onchange=()=>{state.page=0;state.selected=null;renderNative();};
    $('jc-export').onclick=()=>nativeBridge.command('export');
    root.querySelector('.jc-foot').textContent='Collecteur et lecteur locaux · journal enregistré automatiquement';
    setInterval(()=>{if(document.visibilityState==='hidden')return;if(state.tab==='journal'&&!state.selected)renderNative();if(state.tab==='sources')renderNativeSources();if(state.tab==='diagnostic')renderDiagnostic();if(state.tab==='anomalies')renderAnalysis();else refreshAnalysisStatus();},3000);
  }
