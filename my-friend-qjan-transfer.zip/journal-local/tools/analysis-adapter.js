  let analysisPage=0, analysisSelected=null, analysisStatus=null, analysisConfig=null;
  function analysisCall(method,...args){const value=JSON.parse(nativeBridge[method](...args));if(value.error)throw new Error(value.error);return value;}
  function analysisMessage(text,error=false){const box=$('jc-analysis-message');box.textContent=text;box.className=error?'jc-error':'jc-status';box.hidden=false;}
  function analysisTime(ms){return ms?new Date(ms).toLocaleString('fr-CA'):'Heure non renseignée';}
  function refreshAnalysisStatus(){
    if(!nativeBridge)return;
    try{
      const s=JSON.parse(nativeBridge.analysisSummary());analysisStatus=s;
      $('jc-analysis-tab').textContent='Anomalies'+(s.unread?' · '+s.unread:'');
      $('jc-analysis-progress').textContent=s.error||((s.processed||0)+' événements examinés'+(s.busy||s.checkpoint<s.latest?' · analyse en cours…':' · analyse à jour')+'.');
      $('jc-analysis-progress').className=s.error?'jc-error':'jc-sub';
      $('jc-analysis-coverage').textContent=(s.unknown_attribution||0)+' relevés sans attribution à une app unique; '+(s.uncertain_counters||0)+' relevés de volume sans intervalle exploitable. Ils restent dans le journal, sans attribution forcée.';
      if(s.settings&&!analysisConfig)analysisConfig=s.settings;
    }catch(e){$('jc-analysis-progress').textContent='Analyse indisponible : '+e.message;$('jc-analysis-progress').className='jc-error';}
  }
  function renderAnalysis(){
    if(!nativeBridge)return;
    refreshAnalysisStatus();
    if(analysisSelected!==null||$('jc-analysis-settings').open)return;
    try{
      const type=$('jc-analysis-kind').value,unread=$('jc-analysis-unread').checked;
      const result=analysisCall('analysisPage',type,unread,analysisPage*15);
      if(analysisPage&&!result.rows.length){analysisPage=0;renderAnalysis();return;}
      const list=$('jc-analysis-list');list.replaceChildren();
      $('jc-analysis-count').textContent=result.total+' groupe'+(result.total===1?'':'s')+(type==='trace'?' de traces':' de signalements');
      $('jc-analysis-empty').hidden=Boolean(result.rows.length);
      $('jc-analysis-empty').textContent=unread?'Aucun groupe à lire pour ce filtre. Tu peux afficher aussi les groupes déjà vus.':type==='trace'?'Aucune correspondance dans les questions DNS examinées. Les données chiffrées et les opérations internes restent hors de cette recherche.':'Aucune règle déclenchée dans les événements examinés. Cela ne garantit pas l’absence d’anomalies dans les données non collectées.';
      for(const row of result.rows){
        const li=element('li',undefined,'jc-event'),button=element('button'),main=element('span',undefined,'jc-event-main');button.type='button';
        main.append(element('span',analysisTime(row.last_ms),'jc-sub'),element('strong',row.title),element('span',row.actor+' · '+row.occurrences+' observation(s) regroupée(s)','jc-sub'));
        button.append(main,element('span',row.reviewed?'Vu':row.kind==='trace'?'Trace':row.severity==='attention'?'À examiner':'Information','jc-chip'));
        button.onclick=()=>showAnalysis(row);li.append(button);list.append(li);
      }
      const pages=Math.max(1,Math.ceil(result.total/15));$('jc-analysis-pagination').hidden=pages<=1;$('jc-analysis-page').textContent='Page '+(analysisPage+1)+' / '+pages;$('jc-analysis-prev').disabled=!analysisPage;$('jc-analysis-next').disabled=analysisPage>=pages-1;
    }catch(e){analysisMessage(e.message,true);}
  }
  function showAnalysis(row){
    analysisSelected=row.id;const pane=$('jc-analysis-detail');pane.hidden=false;pane.replaceChildren();
    const heading=element('div',undefined,'jc-row jc-between'),close=element('button','Fermer');close.type='button';close.id='jc-analysis-close';close.onclick=()=>{analysisSelected=null;pane.hidden=true;renderAnalysis();};heading.append(element('h3',row.title),close);pane.append(heading);
    pane.append(element('p',row.explanation));
    const dl=element('dl',undefined,'jc-fields');for(const [k,v]of Object.entries({'Application / acteur':row.actor,'Première observation':analysisTime(row.first_ms),'Dernière observation':analysisTime(row.last_ms),'Observations regroupées':row.occurrences,...row.facts}))dl.append(element('dt',k),element('dd',String(v)));pane.append(dl,element('p',row.advice,'jc-note'));
    const seen=element('button',row.reviewed?'Déjà marqué vu':'Marquer vu');seen.type='button';seen.id='jc-analysis-reviewed';seen.disabled=row.reviewed;seen.style.marginTop='12px';seen.onclick=()=>{try{analysisCall('analysisChange','review',String(row.id));row.reviewed=true;seen.disabled=true;seen.textContent='Marqué vu';refreshAnalysisStatus();}catch(e){analysisMessage(e.message,true);}};pane.append(seen);
    pane.append(element('p','Événements sources : échantillon de 12 références maximum. Le journal complet conserve toutes les lignes.','jc-sub'));
    try{
      const data=analysisCall('analysisEvidence',row.id);
      for(const raw of data.events){const source=element('details');source.append(element('summary','#'+raw.id+' · '+(raw.app||'Acteur inconnu')+' · '+raw.action),element('p',raw.timestamp||''),element('pre',JSON.stringify(raw,null,2)));pane.append(source);}
      if(!data.events.length)pane.append(element('p','Les événements référencés ne sont pas disponibles.'));
    }catch(e){pane.append(element('p',e.message,'jc-error'));}
    pane.scrollIntoView({block:'nearest'});
  }
  function initAnalysis(){
    if(!nativeBridge)return;
    refreshAnalysisStatus();
    const quiet=element('select');quiet.id='jc-quiet';quiet.append(new Option('Réduire le bruit','quiet'),new Option('Tout afficher','all'));quiet.value=analysisConfig&&analysisConfig.quiet===false?'all':'quiet';
    const quietLabel=element('label','Détails répétitifs');quietLabel.append(quiet);$('jc-app').parentElement.before(quietLabel);
    quiet.onchange=()=>{state.page=0;state.selected=null;renderNative();};
    const noise=element('p','La vue allégée masque les signaux de vie, les compteurs globaux et les états de batterie. Une recherche consulte toutes les lignes. Aucune ligne n’est effacée.','jc-sub');noise.id='jc-noise-note';$('jc-filter-count').parentElement.after(noise);
    $('jc-analysis-kind').onchange=()=>{analysisPage=0;analysisSelected=null;$('jc-analysis-detail').hidden=true;renderAnalysis();};
    $('jc-analysis-unread').onchange=()=>{analysisPage=0;analysisSelected=null;$('jc-analysis-detail').hidden=true;renderAnalysis();};
    $('jc-analysis-prev').onclick=()=>{analysisPage--;renderAnalysis();};$('jc-analysis-next').onclick=()=>{analysisPage++;renderAnalysis();};
    $('jc-analysis-export').onclick=()=>nativeBridge.command('export-analysis');
    $('jc-analysis-retry').onclick=()=>{try{analysisCall('analysisChange','retry','');refreshAnalysisStatus();}catch(e){analysisMessage(e.message,true);}};
    $('jc-analysis-settings').addEventListener('toggle',()=>{
      if(!$('jc-analysis-settings').open){renderAnalysis();return;}
      refreshAnalysisStatus();analysisConfig=analysisStatus&&analysisStatus.settings||analysisConfig||{};
      for(const key of ['failures','volume','dns','collection','watch','research'])$('jc-rule-'+key).checked=analysisConfig[key]!==false;
      $('jc-rule-count').value=analysisConfig.failure_count||8;$('jc-rule-mib').value=analysisConfig.upload_mib||10;$('jc-rule-domains').value=(analysisConfig.domains||[]).join('\n');
    });
    $('jc-analysis-save').onclick=()=>{
      try{
        const settings={quiet:$('jc-quiet').value==='quiet',failure_count:Number($('jc-rule-count').value),upload_mib:Number($('jc-rule-mib').value),domains:$('jc-rule-domains').value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean)};
        if(!Number.isInteger(settings.failure_count)||!Number.isInteger(settings.upload_mib))throw new Error('Les seuils doivent être des nombres entiers.');
        for(const key of ['failures','volume','dns','collection','watch','research'])settings[key]=$('jc-rule-'+key).checked;
        const result=analysisCall('analysisChange','settings',JSON.stringify(settings));analysisConfig=result.settings;$('jc-analysis-settings').open=false;
        analysisMessage('Règles enregistrées. Elles s’appliquent aux événements qui restent à analyser et aux prochains événements. Les anciens signalements conservent leurs critères.');renderAnalysis();
      }catch(e){analysisMessage(e.message,true);}
    };
  }
  initAnalysis();
