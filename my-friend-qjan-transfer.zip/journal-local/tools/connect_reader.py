from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'tools/reader-base.html').read_text()
s=s.replace('    <button type="button" data-jc-tab="permissions"', '    <button type="button" id="jc-analysis-tab" data-jc-tab="anomalies" aria-pressed="false" aria-controls="jc-pane-anomalies">Anomalies</button>\n    <button type="button" data-jc-tab="permissions"')
s=s.replace('  <section class="jc-pane" id="jc-pane-permissions"', (root/'tools/analysis-pane.html').read_text()+'\n  <section class="jc-pane" id="jc-pane-permissions"')
s=s.replace("['journal','permissions','sources']", "['journal','anomalies','diagnostic','permissions','sources']")
s=s.replace("if(tab==='sources')renderSources(); }", "if(tab==='sources')renderSources(); if(tab==='anomalies')renderAnalysis(); if(tab==='diagnostic')renderDiagnostic(true); }")
s=s.replace("['Fichier importé',source?source.name:'Inconnu']", "[nativeBridge?'Stockage local':'Fichier importé',source?source.name:'Inconnu']")
s=s.replace("['Statut de lecture','Événement rapporté par le fichier; non vérifié sur le téléphone']", "['Statut de lecture',nativeBridge?(['trafic','dns'].includes(event.original.category)?'Métadonnées reçues du VPN local et enregistrées dans la base privée':'État communiqué par Android et enregistré dans la base privée'):'Événement rapporté par le fichier; non vérifié sur le téléphone']")
s=s.replace("element('span',event.destination,'jc-sub')", "element('span',(nativeBridge?(event.original.category==='trafic'?'Destination contactée : ':event.original.category==='dns'?'Nom recherché : ':'Ressource : '):'')+event.destination,'jc-sub')")
s=s.replace("pane.append(fields);", "pane.append(fields); if(nativeBridge&&event.original.source==='ConnectivityManager.onLinkPropertiesChanged')pane.append(element('p','Paramètres réseau reçus : premier relevé ou mise à jour. Un changement de DNS est signalé dans Anomalies seulement après comparaison de deux relevés du même réseau.','jc-note'));")
s=s.replace('    <button type="button" data-jc-tab="sources"', '    <button type="button" data-jc-tab="diagnostic" aria-pressed="false" aria-controls="jc-pane-diagnostic">Diagnostic</button>\n    <button type="button" data-jc-tab="sources"')
s=s.replace('  <section class="jc-pane" id="jc-pane-sources"', (root/'tools/diagnostic-pane.html').read_text()+'\n  <section class="jc-pane" id="jc-pane-sources"')
s=s.replace("pane.append(fields);", "pane.append(fields); nativeDetailExtras(pane,event);")
start=s.index("    const list=$('jc-events');list.replaceChildren();")
end=s.index("    $('jc-empty').hidden=filtered.length>0;",start)
block=s[start:end].replace('filtered.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE)','rows')
s=s[:start]+"    renderRows(filtered.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE));\n"+s[end:]
s=s.replace('  function renderJournal() {','  function renderRows(rows) {\n'+block+'  }\n  function renderJournal() {\n    if(nativeBridge){renderNative();return;}')
s=s.replace('  function renderSources() {','  function renderSources() {\n    if(nativeBridge){renderNativeSources();return;}')
marker='  renderJournal();renderPermissions();renderSources();\n})();'
assert s.count(marker)==1
s=s.replace(marker,(root/'tools/native-adapter.js').read_text()+'\n'+(root/'tools/analysis-adapter.js').read_text()+'\n'+(root/'tools/diagnostic-adapter.js').read_text()+'\n'+marker)
# Add a restrictive CSP for frames: the JS bridge must remain reachable only by the bundled page.
s=s.replace("default-src 'none';", "default-src 'none'; frame-src 'none'; child-src 'none';")
(root/'app/src/main/assets/journal.html').write_text(s)
print('Native reader connected:',len(s.encode()),'bytes')
