  function diagnosticSettings(){const r=JSON.parse(nativeBridge.diagnosticConfigure(JSON.stringify({year:Number($('jt-year').value),utc_offset_minutes:Number($('jt-offset').value),window_seconds:Number($('jt-window').value)})));if(r.error)throw new Error(r.error);return r;}
  function renderDiagnostic(open=false){
    if(!nativeBridge||!nativeBridge.diagnosticSummary)return;
    try{const d=JSON.parse(nativeBridge.diagnosticSummary());if(!d.settings)throw new Error(d.error||'Diagnostic indisponible');
      if(open){$('jt-year').value=d.settings.year;$('jt-offset').value=d.settings.utc_offset_minutes;$('jt-window').value=d.settings.window_seconds;}
      $('jt-files-status').textContent=d.file_status||'';$('jt-diagnostic-status').textContent=d.error||d.activity||`${d.records} lignes de diagnostic disponibles. Aucun accès logcat système en direct.`;
      const imports=$('jt-imports');imports.replaceChildren();for(const row of d.imports||[])imports.append(element('p',`Import ${row.id} · ${row.records} lignes reconnues / ${row.lines_seen} · ${row.member} · ${row.unparsed_lines} lignes non indexées`,'jc-sub'));
      if(d.recovery){const r=JSON.parse(d.recovery);$('jt-recovery-status').textContent=`${r.recovered_events} événements récupérés · document source ${r.document_complete?'complet':'incomplet ou invalide'} · intégrité ${r.source_integrity} · ${r.issue||'aucune erreur de syntaxe détectée'}`;}
    }catch(e){$('jt-diagnostic-status').textContent=e.message;}
  }
  function nativeDetailExtras(pane,event){
    if(!nativeBridge)return;const d=event.original.details||{};
    if(d.uid!==undefined){const p=Array.isArray(d.packages)?d.packages:[];pane.append(element('p',(p.length>1||d.uid===1000)?`UID ${d.uid} partagé · ${p.length} paquets candidats retournés. Processus et service précis non déterminés.`:`UID observé : ${d.uid}. ${d.attribution||''}`,'jc-note'));}
    if(d.tls_observation){pane.append(element('p',`TLS : ${d.tls_observation}${d.tls_sni?' · '+d.tls_sni:''}`));if(d.tls_sni)pane.append(element('p',d.sni_scope||'Nom annoncé par le client; contenu non identifié.','jc-sub'));}
    if(d.security_context&&d.security_context.length){const c=element('details');c.append(element('summary','Contexte de sécurité documenté'));for(const e of d.security_context)c.append(element('p',`${e.package} · ${e.cve} · ${e.documented_product}`),element('p',e.applicability,'jc-note'),element('p',e.interpretation,'jc-sub'));pane.append(c);}
    if(['trafic','dns'].includes(event.original.category)&&nativeBridge.correlate){
      const button=element('button','Croiser avec le diagnostic');button.type='button';button.id='jt-correlate';const output=element('div');output.id='jt-correlation-result';output.setAttribute('aria-live','polite');
      button.onclick=()=>{output.replaceChildren();try{
        const r=JSON.parse(nativeBridge.correlate(Number(event.original.id)));if(r.error)throw new Error(r.error);output.append(element('p',r.interpretation,'jc-note'),element('p',`${r.lines_in_window} lignes dans ±${r.window_ms_each_side/1000} s · ${r.lines_examined} examinées · ${(r.candidates||[]).length} affichées. L’heure comparée est le début observé du flux.`,'jc-sub'));
        const names={temporal:'Heure proche seulement',endpoint_and_time:'Destination mentionnée à proximité',socket_tuple_reported:'Même socket et UID rapportés'};
        for(const row of r.candidates||[]){const item=element('div',undefined,'jc-source');item.append(element('strong',`${names[row.match]||row.match} · PID ${row.pid} · écart ${row.delta_ms} ms`),element('span',`Import ${row.import_id}, ligne ${row.source_line} · ${row.process_name||row.tag||'nom inconnu'} · ${row.time_basis}`,'jc-sub'),element('p',row.scope||'PID non vérifié sur le téléphone.','jc-sub'));output.append(item);}
        const save=element('button','Exporter ce rapprochement');save.type='button';save.id='jt-export-correlation';save.onclick=()=>nativeBridge.command('export-correlation');output.append(save);
      }catch(e){output.append(element('p',e.message,'jc-error'));}};pane.append(button,output);
    }
  }
  if(nativeBridge){
    $('jt-export-lines').onclick=()=>nativeBridge.command('export-lines');$('jt-recover').onclick=()=>nativeBridge.command('recover-file');$('jt-save-recovery').onclick=()=>nativeBridge.command('save-recovered');$('jt-save-last').onclick=()=>nativeBridge.command('save-last-export');
    $('jt-import').onclick=()=>{try{diagnosticSettings();nativeBridge.command('import-diagnostic');}catch(e){$('jt-diagnostic-status').textContent=e.message;}};
    $('jt-save-settings').onclick=()=>{try{diagnosticSettings();$('jt-diagnostic-status').textContent='Fenêtre enregistrée. Les horloges des anciens imports restent inchangées.';}catch(e){$('jt-diagnostic-status').textContent=e.message;}};
  }
