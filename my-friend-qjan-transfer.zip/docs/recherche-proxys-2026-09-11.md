# Recherche de proxys pour Journal local

Recherche du 11 septembre 2026. Appareil indiqué : Samsung SM-S731W, Android 16, usage sans ordinateur. Cette note décrit des raccords vérifiés dans les sources et un montage à réaliser. Aucun nouveau proxy n’a été installé, aucun certificat ajouté et aucun APK recompilé pendant cette recherche. Les dix événements Meet évoqués oralement n’ont pas été fournis avec leurs détails.

## Le raccord retenu

Conserver le VPN de Journal local et diriger les connexions TCP sélectionnées vers un moteur mitmproxy local. Récupérer les événements du proxy pour les rattacher aux connexions déjà journalisées. Ce raccord peut réutiliser le module Android PCAPdroid-mitm; son intégration directe demande encore un développement et une validation sur le téléphone.

Deux extrémités de ce raccord sont présentes dans le code :

| Extrémité | Élément vérifié | Conséquence |
|---|---|---|
| Bibliothèque zdtun déjà incluse dans notre application | `zdtun_set_socks5_proxy` et `zdtun_conn_proxy` | Permet de sélectionner des connexions TCP à envoyer vers un proxy SOCKS5. Notre relais actuel n’active pas ce chemin. |
| Module PCAPdroid-mitm | `MitmService.getMitmproxyArgs()` lance le mode SOCKS5 sur `127.0.0.1` | Fournit le moteur d’inspection local auquel raccorder le relais. |
| Interface du module | `MitmAPI`, messages de démarrage, arrêt et récupération du certificat | Fournit un point d’intégration explicite. Le format de retour, le cycle de vie et la corrélation restent à implémenter. |

Sources : [interface zdtun](https://github.com/emanuele-f/zdtun/blob/master/zdtun.h), [service du module MITM](https://github.com/emanuele-f/PCAPdroid-mitm/blob/master/app/src/main/java/com/pcapdroid/mitm/MitmService.java), [MitmAPI](https://github.com/emanuele-f/PCAPdroid-mitm/blob/master/app/src/main/java/com/pcapdroid/mitm/MitmAPI.java).

```mermaid
flowchart TD
    A[Applications] --> V[VPN de Journal local]
    V -->|TCP sélectionné| P[Proxy MITM local]
    P -->|Connexion au serveur| S[Internet]
    V -->|UID, IP et compteurs| J[Journal]
    P -->|Requêtes et réponses accessibles| J
```

Le diagramme décrit le trajet sortant; les réponses suivent le trajet inverse. Les autres flux gardent leur collecte de métadonnées. Le chemin SOCKS5 vérifié dans notre bibliothèque concerne TCP : il ne fournit pas le déchiffrement d’HTTP/3 sur QUIC.

Le VPN dirige les paquets. Le proxy établit une session TLS avec l’application et une autre avec le serveur. Pour inspecter le contenu, l’application doit accepter le certificat du proxy; déplacer le proxy dans le trajet ne retire pas cette condition. Le pinning ou une autre couche de chiffrement demandent un traitement distinct. Source : [certificats et pinning dans mitmproxy](https://github.com/mitmproxy/mitmproxy/blob/main/docs/src/content/concepts/certificates.md).

## Autres projets examinés

| Projet | Résultat de l’examen | Utilité pour ce téléphone |
|---|---|---|
| ProxyPin | Application Flutter avec VPN Android Kotlin et proxy HTTP(S). Liaisons entre sélection de protocole, destination du proxy et traitement HTTP visibles dans les sources. | Exemple concret de moteur local et d’interface HTTP. Adaptations nécessaires avant réutilisation. |
| NetBare-Android | Framework Java/Kotlin qui dirige les paquets VPN vers des proxys locaux; inclut des moteurs TLS et des intercepteurs HTTP. | Bon exemple d’intégration dans une application Android. Ancien environnement de compilation; compatibilité Android 16 non établie. |
| HTTP Toolkit Android | Le VPN Android réécrit et transmet le trafic vers l’application HTTP Toolkit sur ordinateur. | Raccord VPN/proxy démontré, mais parcours officiel dépendant d’un ordinateur. |
| mitmproxy en mode WireGuard | Reçoit un tunnel VPN et inspecte les protocoles pris en charge. HTTP/3 disponible dans ce mode. | Piste pour une couverture de protocoles plus large, avec un hôte exécutant mitmproxy à prévoir. |

Sources : [ProxyPin](https://github.com/wanghongenpin/proxypin), [NetBare](https://github.com/MegatronKing/NetBare-Android), [HTTP Toolkit Android](https://github.com/httptoolkit/httptoolkit-android), [modes mitmproxy](https://docs.mitmproxy.org/stable/concepts/modes/), [protocoles mitmproxy](https://docs.mitmproxy.org/stable/concepts/protocols/).

La documentation mitmproxy limite actuellement HTTP/3 à QUIC version 1 et signale une validation essentiellement faite avec cURL. Elle indique aussi une prise en charge IPv6 limitée dans son serveur WireGuard. Ce montage ne peut donc pas être annoncé comme capturant ou déchiffrant tout le trafic du Samsung.

## Points concrets relevés dans ProxyPin

Révision consultée : `eb2cb1af96be46435f905c8d23c89be7eef2be56`, commit du 10 septembre 2026. Le dépôt n’était pas archivé. Ce repère décrit les sources, sans établir le contenu exact d’un APK distribué.

- `ConnectionHandler.getProxyAddress()` choisit le proxy pour les protocoles détectés comme HTTP ou TLS. `initProxyConnect()` connecte le canal à cette destination. C’est un raccord réel entre le VPN et le proxy. [Code](https://github.com/wanghongenpin/proxypin/blob/eb2cb1af96be46435f905c8d23c89be7eef2be56/android/app/src/main/kotlin/com/network/proxy/vpn/ConnectionHandler.kt).
- `CertificateManager.certificateFile()` et `privateKeyFile()` recopient les ressources de certificat et de clé du projet lorsqu’aucun fichier local n’existe. L’interface propose de générer une nouvelle autorité. La réutilisation doit prévoir une clé propre à l’installation. [Gestion des certificats](https://github.com/wanghongenpin/proxypin/blob/eb2cb1af96be46435f905c8d23c89be7eef2be56/lib/network/util/crts.dart).
- `Channel.secureSocket()` et `startSecureSocket()` utilisent `onBadCertificate: (...) => true`. Une intégration destinée au journal doit conserver une validation explicite des serveurs distants. [Canaux TLS](https://github.com/wanghongenpin/proxypin/blob/eb2cb1af96be46435f905c8d23c89be7eef2be56/lib/network/channel/channel.dart).
- Pour l’attribution, `ProcessInfoManager` utilise l’UID de connexion, puis retourne le premier paquet lisible dans `getPackagesForUid()`. Ce mécanisme ne résout pas l’ambiguïté des UID partagés : afficher ce paquet ne démontre pas qu’il a initié le flux. [Attribution](https://github.com/wanghongenpin/proxypin/blob/eb2cb1af96be46435f905c8d23c89be7eef2be56/android/app/src/main/kotlin/com/network/proxy/vpn/util/ProcessInfoManager.kt).
- Le constructeur du VPN examiné configure une adresse et une route IPv4; aucune prise en charge IPv6 complète n’a été établie par cet examen. [Service VPN](https://github.com/wanghongenpin/proxypin/blob/eb2cb1af96be46435f905c8d23c89be7eef2be56/android/app/src/main/kotlin/com/network/proxy/ProxyVpnService.kt).

Ces constats motivent une adaptation ciblée; ils n’établissent pas une intention malveillante du projet.

## Ce que notre application compte réellement

Source examinée : archive livrée `rapport-01-work/journal-local-sources.zip`, base de la version 0.4.0. Fichiers internes `app/src/main/cpp/relay.c` et `app/src/main/java/fr/erick/journallocal/NetworkCaptureService.java`.

Le relais vérifie les compteurs environ toutes les cinq secondes. Il évite les relevés intermédiaires lorsque les volumes n’ont pas changé. Il journalise aussi les ouvertures, fermetures et autres événements. Le nombre de lignes n’est donc pas un nombre de messages applicatifs ni de requêtes HTTP.

Dans `NetworkCaptureService`, les champs `tx_bytes` et `rx_bytes` sont cumulatifs par connexion. Le champ `counter_mode` dit explicitement : « Cumul du flux; ne pas additionner les instantanés ». Le libellé de la liste est construit avec `↑ ... o / ↓ ... o`, en octets.

Conséquences pour l’observation de Meet :

- Une ligne affichant 3 000 o correspond à environ 3 ko. Une ligne affichant 3 000 ko correspondrait à environ 3 Mo; il faut lire l’unité exacte.
- Des relevés successifs d’un même flux ne s’additionnent pas. Par exemple, un cumul qui passe de 2 000 à 3 000 octets indique 1 000 octets supplémentaires entre les deux relevés.
- Dix lignes affichées presque simultanément peuvent décrire plusieurs flux, leurs états ou leurs fermetures. Leur nombre ne démontre pas dix messages envoyés dans cette seconde.
- Si dix flux distincts ont réellement envoyé chacun 2 à 3 Mo dans une seconde, le total serait 20 à 30 Mo. Cette hypothèse n’est pas vérifiée par les données reçues pendant cette recherche.

Pour mesurer la rafale, il faut les horodatages, unités, `flow_id`, UID/paquets, destinations et compteurs précédents. L’absence d’utilisation volontaire de Meet est un élément de contexte à conserver; elle ne détermine pas le contenu des transferts.

## Travail d’intégration à réaliser

1. Ajouter au relais la sélection des flux TCP vers SOCKS5 et une configuration de proxy local.
2. Adapter le pilotage de `MitmAPI`, la réception des événements et la corrélation entre les connexions originales et proxifiées. Préserver l’UID initial; ne pas attribuer tout le trafic au processus proxy.
3. Gérer les sockets sortants du proxy pour éviter leur retour dans le VPN. Valider Wi-Fi, cellulaire et changements de réseau.
4. Prévoir une autorité de certification propre à l’installation, la vérification des serveurs distants et l’affichage du résultat du déchiffrement. Une application qui refuse le certificat doit rester identifiée comme telle.
5. Remplacer l’ambiguïté visuelle des compteurs par des unités explicites, un total par flux et le volume supplémentaire par intervalle. Conserver les originaux et signaler les pertes de collecte.
6. Valider sur le Samsung une requête HTTPS connue, puis une capture ciblée de Meet. Comparer connexion unique, requêtes réellement décodées et volumes mesurés. Garder QUIC, IPv6 et UID partagés comme limites explicites tant qu’ils ne sont pas couverts et testés.

Le manifeste du module MITM déclare notamment `MANAGE_EXTERNAL_STORAGE`, présenté dans le source comme servant aux modules Python écrivant dans les répertoires publics. Une adaptation limitée au journal peut être conçue autour du stockage privé et d’un export choisi, sans recopier ce besoin automatiquement. [Manifeste du module](https://github.com/emanuele-f/PCAPdroid-mitm/blob/master/app/src/main/AndroidManifest.xml).

## Crédit OpenAI API

Le crédit API indiqué par l’utilisateur peut financer des appels à un modèle pour des travaux de programmation ou l’analyse d’extraits sélectionnés. Un exécuteur API séparé et sa configuration sécurisée sont nécessaires. Le crédit ne recharge pas directement cette conversation Work; Codex accepte une clé API pour les parcours locaux et programmatiques documentés. Aucun appel API payant n’a été lancé pendant cette recherche. [Authentification OpenAI](https://learn.chatgpt.com/docs/auth), [disponibilité et facturation](https://learn.chatgpt.com/docs/pricing).

Le routage, la capture réseau et le déchiffrement TLS du montage proposé n’exigent pas de requête à un modèle d’IA pour chaque paquet.
